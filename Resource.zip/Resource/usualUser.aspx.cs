﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ResourceManage;

public partial class _usualUser : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["LoginName"]) == "")
        {
            Response.Write("<script language=javascript>alert('请先登录')</script>");
            Response.Redirect("./Default.aspx");
            return;
        }
        if (!IsPostBack)
        {
            this.lbUserName.Text = (string)Session["UserName"];
            this.lbUserID.Text = (string)Session["LoginID"];
        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Session["UserName"] = "";
        Session["LoginName"] = "";
        Session["LoginID"] = "";
        Session["LoginTime"] = "";
        Session["Level"] = "";
        Response.Redirect("./Default.aspx");
    }
}
