﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ResourceManage;

public partial class control_addJobSalary : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["LoginName"]) == "")
        {
            Response.Write("<script language=javascript>alert('请先登录')</script>");
            Response.Redirect("../Default.aspx");
            return;
        }
       
        if (!IsPostBack)
        {
            this.ddlJob.DataBind();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)//添加
    {
        bool ret = JobSalaryManage.AddJobSalary(this.ddlJob.Text, Convert.ToInt16(this.txbSalary.Text));
        if (ret)
        {
            Response.Write("<script lanaguage=javascript>alert('添加岗位基本工资信息成功!')</script>");
        }
        else
        {
            Response.Write("<script lanaguage=javascript>alert('添加失败!')</script>");
        }
    }
    protected void Button2_Click(object sender, EventArgs e)//重置
    {
        this.txbSalary.Text = "";
    }
    protected void ddlJob_DataBinding(object sender, EventArgs e)
    {
        DataView dv = EmployeeManage.GetAllJob();
        for (int i = 0; i < dv.Count; i++)
        {
            string job = dv[i][0].ToString();
            ListItem list1 = new ListItem(job, job);
            ddlJob.Items.Add(list1);
        }
    }
}
