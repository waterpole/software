﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ResourceManage;

public partial class control_addUser : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["LoginName"]) == "")
        {
            Response.Write("<script language=javascript>alert('请先登录')</script>");
            Response.Redirect("../Default.aspx");
            return;
        }
        if (!IsPostBack)
        {
        }
    }
    protected void ddlType_SelectedIndexChanged(object sender, EventArgs e)
    {
        string type = this.ddlType.Text;
        if (type.Equals("系统管理员")||type.Equals("部门管理员"))
        {
            this.Label1.Text = "用户名:";
        }
        else if (type.Equals("普通员工"))
        {
            this.Label1.Text = "职工号:";
        }
    }
    protected void Button1_Click(object sender, EventArgs e)//添加按钮
    {
        User user = new User();
        string type = this.ddlType.Text;
        user.UserPwd = this.txbPwd.Text;
        user.UserName = this.txbUserName.Text;
        user.LoginTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd"));
        if (type.Equals("系统管理员"))
        {
            user.UserLevel = 0;
        }
        else if (type.Equals ("部门管理员"))
        {
            user.UserLevel = 1;
        }
        else
        {
            int id =Convert.ToInt32( this.txbUserName.Text);
            if (!EmployeeManage.IfExistId(id))
            {
                Response.Write("<script language=javascript>alert('不存在这样的职工ID号!')</script>");
                return;
            }
            else
            {
                user.UserLevel = 2;
            }
        }
        bool ret = UserManage.AddUserInfo(user);
        if (ret)
        {
            Response.Write("<script language=javascript>alert('添加成功!')</script>");
        }
        else
        {
            Response.Write("<script language=javascript>alert('添加失败!')</script>");
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        this.txbPwd.Text = "";
        this.txbUserName.Text = "";
    }
}
