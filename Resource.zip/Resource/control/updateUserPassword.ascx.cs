﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ResourceManage;

public partial class control_updateUserPassword : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["LoginName"]) == "")
        {
            Response.Write("<script language=javascript>alert('请先登录')</script>");
            Response.Redirect("../Default.aspx");
            return;
        }
        
        if (!IsPostBack)
        {
            this.lbUserName.Text = (string)Session["UserName"];
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string oldPwd = this.txbPwd.Text;
        bool state = UserManage.IfExistPwd(Session["LoginName"].ToString(), oldPwd);
        if (state)
        {
            string pwd = this.txbNewPwd2.Text;
            bool ret = UserManage.UpdateUserPwd((string)Session["LoginName"], pwd);
            if (ret)
            {
                Response.Write("<script language=javascript>alert('密码更新成功!')</script>");
            }
            else
            {
                Response.Write("<script language=javascript>alert('密码更新失败!')</script>");
            }
        }
        else
        {
            Response.Write("<script language=javascript>alert('输入的旧密码不正确!')</script>");
        }
        
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        this.txbNewPwd1.Text = "";
        this.txbNewPwd2.Text = "";
        this.txbPwd.Text = "";
    }
}
