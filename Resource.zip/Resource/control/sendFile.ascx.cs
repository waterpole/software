﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using ResourceManage;

public partial class control_sendFile : System.Web.UI.UserControl
{
    public  static string path;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["LoginName"]) == "")
        {
            Response.Write("<script language=javascript>alert('请先登录')</script>");
            Response.Redirect("../Default.aspx");
            return;
        }
       
        if (!IsPostBack)
        {
            this.ddlName.DataSource = EmployeeManage.GetAllEmployeeInfo();
            this.ddlName.DataTextField = "Name";
            this.ddlName.DataValueField = "Name";
            this.ddlName.DataBind();
        }
    }

    protected void Button1_Click(object sender, EventArgs e)//发送按钮
    {
        //将附件传送到服务器上
        string str = this.FileUpload1.PostedFile.FileName;//取附件上的文件绝对路径
        string ss = str.Substring(str.LastIndexOf("\\") + 1);//附件上的文件名
        string s = Server.MapPath("..\\file\\" + ss);//附件上的文件相对路径
        path = "..\\file\\" + ss;

        string filesender=(string)Session["LoginName"];

        bool ret = FileManage.AddFileInfo(filesender, ddlName.Text, txbTitle.Text, DateTime.Today, txbContent.Text, path, ss,false);
        if (ret)
        {
            Response.Write("<script language=javascript>alert('文件传送成功')</script>");
        }
        else
        {
            Response.Write("<script language=javascript>alert('网络故障,文件传送失败! ')</script>");
        }
        if (str == string.Empty) return;
        this.FileUpload1.PostedFile.SaveAs(s);//保存上载文件的内容
    }


    protected void Button2_Click(object sender, EventArgs e)//重置按钮
    {
        this.txbTitle.Text = "";
        this.txbContent.Text = "";
    }
}
