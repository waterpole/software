﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ResourceManage;

public partial class control_employee : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["LoginName"]) == "")
        {
            Response.Write("<script language=javascript>alert('请先登录')</script>");
            Response.Redirect("../Default.aspx");
            return;
        }
       
        if (!IsPostBack)
        {
            this.ddlDeptName.DataBind();
        }
    }
    protected void ddlDeptName_DataBinding(object sender, EventArgs e)
    {
        ListItem list = new ListItem("---全部---");
        this.ddlDeptName.Items.Add(list);
        DataView dv = DepartmentManage.GetAllDeptName();
        for (int i = 0; i < dv.Count; i++)
        {
            string deptname = Convert.ToString(dv[i][0]).Trim();
            ListItem list1 = new ListItem(deptname, deptname);
            this.ddlDeptName.Items.Add(list1);
        }
    }
 

    protected void find_Click(object sender, EventArgs e)
    {
        if (this.ddlDeptName.Text == "---全部---")
        {
            GridView1.DataSource = EmployeeManage.GetAllEmployeeInfo();
            GridView1.DataBind();
        }
        else 
        {
            string deptname = this.ddlDeptName.Text;
            GridView1.DataSource = EmployeeManage.GetAllEmpInfoByDeptName(deptname);
            GridView1.DataBind();
        }
    }


    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        bool ret = EmployeeManage.DeleteEmpInfoByID(Convert.ToInt16( this.GridView1.DataKeys[e.RowIndex].Value));
        if (ret)
        {
            Response.Write("<script language=javascript>alert('删除员工信息成功!')</script>");
        }
        else
        {
            Response.Write("<script language=javascript>alert('删除失败!')</script>");
        }
        dataBind();
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        dataBind();
    }

    private void dataBind()
    {
        GridView1.DataSource = EmployeeManage.GetAllEmployeeInfo();
        GridView1.DataBind();
    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        string Id = GridView1.DataKeys[e.NewEditIndex].Value.ToString();
        Response.Redirect("./editEmployee.aspx?id='" + Id + "'");
    }

}
