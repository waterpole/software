﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using ResourceManage;

public partial class control_userLogin : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Convert.ToString(Session["LoginName"]) == "")
            {
                if (!IsPostBack)
                {
                    this.Label1.Text = RandomNum(4);
                }
            }
        }
        catch (SqlException ex)
        {
            Response.Write(ex.ToString());
        }
       
    }

    protected string RandomNum(int n)//生成随机数函数
    {
        string strchar="0,1,2,3,4,5,6,7,8,9,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z";
        string[] VcArray=strchar.Split(',');
        string VNum="";
        int temp=-1;//记录上次随机数值,尽量避免产生相邻的随机数
        Random rand=new Random ();
        for(int i=1;i<n+1;i++)//采用一个简单的算法以保证生成随机数的不同
        {
            if(temp!=-1)
            {
                rand=new Random (i*temp*unchecked((int )DateTime.Now.Ticks));
            }
            int t=rand.Next(61);
            if(temp!=-1&&temp==t)
            {
                return RandomNum(n);
            }
            temp=t;
            VNum+=VcArray[t];
        }
        return VNum;//返回生成的随机数
    }
    
    protected void ddlType_SelectedIndexChanged(object sender, EventArgs e)
    {
        string type = this.ddlType.Text;
        try
        {
            if (type.Equals("系统管理员") || type.Equals("部门管理员"))
            {
                this.lbUser.Text = "用户名:";
            }
            else if (type == "普通用户")
            {
                this.lbUser.Text = "职工号:";
            }
        }
        catch (Exception ee)
        {
            string msg = ee.Message;
        }
        
    }
    protected void Button1_Click(object sender, EventArgs e)//登录按键
    {
        if (this.number.Text == "" || this.number.Text != this.Label1.Text)
        {
            Response.Write("<script language=javascript>alert('验证码不正确!')</script>");
            return;
        }
        string type = this.lbUser.Text.Substring(0,this.lbUser.Text.Length-1);
        string username = this.txbUserName.Text;
        string pwd = this.txbPwd.Text;
        UserManage u = new UserManage();
        int i=UserManage.GetInfoCount(username,pwd);
        if (i > 0)
        {//登录成功
            UserManage.UpdateLoginTime(username);
            Session["LoginName"] = this.txbUserName.Text;//登录用户的职工号
            if (type == "用户名")
            {
                Session["UserName"] = this.txbUserName.Text;
                Session["LoginID"] ="";
                
                
            }
            else
            {
                Session["UserName"] = EmployeeManage.GetNameById(Convert.ToInt16( username.ToString()));//职工名字
                Session["LoginID"] = this.txbUserName.Text ;
            }
            if (this.ddlType.Text == "系统管理员")
            {
                Session["Level"] = 0;
                Response.Redirect("admin.aspx");
                
            }
            else if (this.ddlType.Text == "部门管理员")
            {
                Session["Level"] = 1;
                Response.Redirect("departmentAdmin.aspx");
                
            }
            else
            {
                Session["Level"] = 2;
                Response.Redirect("usualUser.aspx");
                
            }
        }
        else
        {
            Response.Write("<script language=javascript>alert('用户名或密码不正确!')</script>");
        }
    }
   
}
