﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ResourceManage;
using System.IO;

public partial class control_fileList : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["LoginName"]) == "")
        {
            Response.Write("<script language=javascript>alert('请先登录')</script>");
            Response.Redirect("../Default.aspx");
            return;
        }
        GridView1.DataSource = FileManage.GetFileInfoByAccepter((string)Session["UserName"]);
        GridView1.DataKeyNames = new string[] { "FileID" };
        GridView1.DataBind();
    }


    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        //删除文件(服务器)
        DataSet ds = FileManage.GetFileByFileId(Convert.ToInt32( GridView1.DataKeys[e.RowIndex].Value));
        DataRow[] row = ds.Tables[0].Select();//从结果中筛选条件
        foreach (DataRow rs in row)//将检索到的数据逐一,循环添加到Listbox1中
        {
            FileInfo file = new FileInfo(MapPath(rs["Path"].ToString()));
            file.Delete();//删除文件
        }
        //清除数据
        FileManage.DeleteFileByFileId(Convert.ToInt32( this.GridView1.DataKeys[e.RowIndex].Value));
        this.GridView1.DataSource = FileManage.GetFileInfoByAccepter((string)Session["UserName"]);
        this.GridView1.DataBind();
    }

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        GridView1.DataBind();
    }
}
