﻿
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ResourceManage;

public partial class control_recruit : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["LoginName"]) == "")
        {
            Response.Write("<script language=javascript>alert('请先登录')</script>");
            Response.Redirect("../Default.aspx");
            return;
        }
        
        if (!IsPostBack)
        {
            databind();
        }
    }

    protected void databind()
    {
        GridView1.DataSource = RecruitManage.GetAllRecruitInfo();
        GridView1.DataBind();
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        databind();
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        for (int i = 0; i < this.GridView1.Rows.Count; i++)
        {
            DataKey key = GridView1.DataKeys[i];
            Label lbPost = (Label)this.GridView1.Rows[i].FindControl("a");
            lbPost.Attributes.Add("onclick", "openURL(" + key.Value + ")");
            lbPost.Attributes.Add("onmouseout", "this.style.color=c");
            lbPost.Attributes.Add("onmouseover", "c=this.style.color;this.style.color='#0000ff'");
        }
    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        string id;
        id =GridView1.DataKeys[e.NewEditIndex].Value.ToString();
        Response.Redirect("./editRecruit.aspx?id='"+id+"'");
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        int  id =Convert.ToInt32( GridView1.DataKeys[e.RowIndex].Value.ToString());
        bool ret = RecruitManage.DeleteRecruitInfo(id);
        if (ret)
        {
            Response.Write("<script language=javascript>alert('删除成功!')</script>");
        }
        else
        {
            Response.Write("<script language=javascript>alert('删除失败!')</script>");
        }
        databind();
    }
}
