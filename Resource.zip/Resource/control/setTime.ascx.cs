﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ResourceManage;

public partial class control_setTime : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["LoginName"]) == "")
        {
            Response.Write("<script language=javascript>alert('请先登录')</script>");
            Response.Redirect("../Default.aspx");
            return;
        }
      
        if (!IsPostBack)
        {
            databind();
        }
    }

    public  void databind()
    {
        DataSet ds = new DataSet();
        ds = SignstateManage.GetAllInfo();
        DataRow[] row1 = ds.Tables[0].Select("SignStateID=1");
        foreach (DataRow rs in row1)
        {
            this.txb1.Text = Convert.ToDateTime(rs["Time"]).ToString("HH:mm:ss");
        }
        DataRow[] row2 = ds.Tables[0].Select("SignStateID=2");
        foreach (DataRow rs in row2)
        {
            this.txb2.Text = Convert.ToDateTime(rs["Time"]).ToString("HH:mm:ss");
        }
        DataRow[] row3 = ds.Tables[0].Select("SignStateID=3");
        foreach (DataRow rs in row3)
        {
            this.txb3.Text = Convert.ToDateTime(rs["Time"]).ToString("HH:mm:ss");
        }
        DataRow[] row4 = ds.Tables[0].Select("SignStateID=4");
        foreach (DataRow rs in row4)
        {
            this.txb4.Text = Convert.ToDateTime(rs["Time"]).ToString("HH:mm:ss");
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        DateTime time1 = Convert.ToDateTime(this.txb1.Text);
        DateTime time2 = Convert.ToDateTime(this.txb2.Text);
        DateTime time3 = Convert.ToDateTime(this.txb3.Text);
        DateTime time4 = Convert.ToDateTime(this.txb4.Text);
        bool ret1 = SignstateManage.UpdateInfo(1, time1);
        bool ret2 = SignstateManage.UpdateInfo(2, time2);
        bool ret3 = SignstateManage.UpdateInfo(3, time3);
        bool ret4 = SignstateManage.UpdateInfo(4, time4);
        if (ret1 && ret2 && ret3 && ret4)
        {
            Response.Write("<script language=javascript>alert('上下班时间设置成功！')</script>");
        }
        else
        {
            Response.Write("<script language=javascript>alert('上下班时间设置失败！')</script>");
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        this.txb1.Text = "";
        this.txb2.Text="";
        this.txb3.Text="";
        this.txb4.Text = "";
    }
}
