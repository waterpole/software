﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ResourceManage;

public partial class control_showCheckItem : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["LoginName"]) == "")
        {
            Response.Write("<script language=javascript>alert('请先登录')</script>");
            Response.Redirect("../Default.aspx");
            return;
        }
      
        if (!IsPostBack)
        {
            databind();
        }
    }

    protected void databind()
    {
        GridView1.DataSource = CheckItemManage.GetAllItemInfo();
        GridView1.DataBind();
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        databind();
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        int itemId = Convert.ToInt16(GridView1.DataKeys[e.RowIndex].Value);
        bool ret = CheckItemManage.DeleteItemInfoById(itemId);
        if (ret)
        {
            Response.Write("<script language=javascript>alert('删除成功!')</script>");
        }
        else
        {
            Response.Write("<script language=javascript>alert('删除失败!')</script>");
        }
    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex= e.NewEditIndex;
        databind();
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        int itemId = Convert.ToInt16(GridView1.DataKeys[e.RowIndex].Value);
        TextBox content = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txbContent");
        TextBox descript = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txbDescript");
        TextBox weight = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txbWeight");
        CheckItem item = new CheckItem();
        item.ItemID = itemId;
        item.ItemContent = content.Text.Trim();
        item.ItemDescript = descript.Text.Trim();
        item.ItemWeight = Convert.ToInt16(weight.Text.Trim());
        CheckItemManage.UpdateInfo(item);
        GridView1.EditIndex = -1;
        databind();
    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        databind();
    }
}
