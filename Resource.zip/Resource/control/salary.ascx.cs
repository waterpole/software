﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ResourceManage;

public partial class control_salary : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["LoginName"]) == "")
        {
            Response.Write("<script language=javascript>alert('请先登录')</script>");
            Response.Redirect("../Default.aspx");
            return;
        }
       
        if (!IsPostBack)
        {
            this.ddlDeptName.DataBind();
            this.ddlYear.DataBind();
        }
        
    }

    protected void databind()
    {
        GridView1.DataSource = SalaryManage.GetAllInfo(this.ddlDeptName.Text, this.ddlYear.Text, this.ddlMonth.Text);
        GridView1.DataBind();
    }
    protected void ddlDeptName_DataBinding(object sender, EventArgs e)
    {
        DataView dv = DepartmentManage.GetAllDeptName();
        for (int i = 0; i < dv.Count; i++)
        {
            string deptname = dv[i][0].ToString();
            ListItem list = new ListItem(deptname, deptname);
            this.ddlDeptName.Items.Add(list);
        }
    }
    protected void ddlYear_DataBinding(object sender, EventArgs e)
    {
        DataView dv = SignManage.GetAllYear();
        for (int i = 0; i < dv.Count; i++)
        {
            string year = dv[i][0].ToString();
            ListItem list = new ListItem(year, year);
            this.ddlYear.Items.Add(list);
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        databind();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        databind(); 
    }
}
