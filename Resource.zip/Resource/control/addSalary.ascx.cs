﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ResourceManage;

public partial class control_addSalary : System.Web.UI.UserControl
{
    public static int BaseSalary=0;//岗位工资
    public static int ResultsWage = 0;//绩效工资
    public static int AttendanceSalary = 0;//全勤奖
    public static int OverTimePay = 0;//加班费
    public static int Total = 0;//工资总和
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["LoginName"]) == "")
        {
            Response.Write("<script language=javascript>alert('请先登录')</script>");
            Response.Redirect("../Default.aspx");
            return;
        }
       
        if (!IsPostBack)
        {
            this.ddlYear.DataBind();
            this.ddlDeptName.DataBind();
        }
    }
    protected void ddlDeptName_DataBinding(object sender, EventArgs e)
    {
        DataView dv = DepartmentManage.GetAllDeptName();
        for (int i = 0; i < dv.Count; i++)
        {
            string deptname = dv[i][0].ToString();
            ListItem list = new ListItem(deptname, deptname);
            this.ddlDeptName.Items.Add(list);
        }
    }
    protected void ddlID_DataBinding(object sender, EventArgs e)
    {
        DataView dv = EmployeeManage.GetAllIdByDeptName(this.ddlDeptName.Text);
        for (int i = 0; i < dv.Count; i++)
        {
            string id = dv[i][0].ToString();
            ListItem list = new ListItem(id, id);
            this.ddlID.Items.Add(list);
        }
    }
    protected void Button1_Click(object sender, EventArgs e)//总计
    {
        Total = BaseSalary + ResultsWage + AttendanceSalary + OverTimePay;
        lbAddUp.Text = Total.ToString();
    }
    protected void ddlDeptName_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.ddlID.Items.Clear();
        this.ddlID.DataBind();
    }
    protected void ddlID_SelectedIndexChanged(object sender, EventArgs e)
    {
        int id =Convert.ToInt16( this.ddlID.Text);
        DataView dv = SalaryManage.GetSomeInfoById(id);
        this.lbName.Text = dv[0][0].ToString();
        this.lbJob.Text = dv[0][1].ToString();
        this.lbSalary.Text = dv[0][2].ToString();
        BaseSalary =Convert.ToInt32(dv[0][2]);
        //绩效工资的计算
        int avgGrade = CheckResultManage.GetAvgGrade(id);//总的平均绩效成绩
        int totalsalary = TypeSalaryManage.GetInfoByType("绩效基础工资");
        if (avgGrade >= 100)
        {
            this.lbResultsWage.Text =totalsalary.ToString();
            ResultsWage = totalsalary;
        }
        else
        {
            this.lbResultsWage.Text =Convert.ToString(totalsalary * avgGrade * 0.01);
            ResultsWage =Convert.ToInt16(totalsalary * avgGrade * 0.01);
        }

        //全勤奖
        int total = SignManage.LateOrQuitTime(id);
        if (total > 0)
        {
            this.lbAttedance.Text ="0";

        }
        else
        {
            this.lbAttedance.Text =TypeSalaryManage.GetInfoByType("全勤奖").ToString();
            AttendanceSalary = TypeSalaryManage.GetInfoByType("全勤奖");
        }

        //加班费
        int overtime=0;
        DataView dv1 = SignManage.GetOverTimeInfo(id, this.ddlYear.Text, this.ddlMonth.Text);
        int pay = TypeSalaryManage.GetInfoByType("加班费");
        for (int i = 0; i < dv1.Count; i++)
        {
            int month = Convert.ToDateTime(dv1[i][0].ToString()).Month;
            if(month==1||month==5||month==10)
            {
                switch (month)
                {
                    case 1:
                        {
                            int day = Convert.ToDateTime(dv1[i][0].ToString()).Day;
                            if (day == 1)//元旦
                            {
                                overtime += Convert.ToInt16(dv1[i][1].ToString()) * 3;
                            }
                            else overtime += Convert.ToInt16(dv1[i][1].ToString());
                            break;
                        }
                    case 5:
                        {
                            int day = Convert.ToDateTime(dv1[i][0].ToString()).Day;
                            if (day == 1 || day == 2 || day == 3)//劳动节
                            {
                                overtime += Convert.ToInt16(dv1[i][1].ToString()) * 3;
                            }
                            else overtime += Convert.ToInt16(dv1[i][1].ToString());
                            break;
                        }
                    case 10:
                        {
                            int day = Convert.ToDateTime(dv1[i][0].ToString()).Day;
                            if (day == 1 || day == 2 || day == 3)//国庆节
                            {
                                overtime += Convert.ToInt16(dv1[i][1].ToString()) * 3;
                            }
                            else overtime += Convert.ToInt16(dv1[i][1].ToString());
                            break;
                        }
                    default:break;
                }
            }
            else if (Convert.ToDateTime(dv1[i][0].ToString()).DayOfWeek.ToString().Equals("6") || Convert.ToDateTime(dv1[i][0].ToString()).DayOfWeek.ToString().Equals("0"))//休息日
            {
                overtime += Convert.ToInt16(dv1[i][1].ToString()) * 2;
            }
            else //工作日
            {
                overtime +=Convert.ToInt16( Convert.ToInt16(dv1[i][1].ToString()) * 1.5);
            }
        }
        this.lbOverTimePay.Text =Convert.ToString(overtime * pay);
        OverTimePay = overtime * pay;
    }
    protected void ddlYear_DataBinding(object sender, EventArgs e)
    {
        DataView dv = SignManage.GetAllYear();
        for (int i = 0; i < dv.Count; i++)
        {
            string year = dv[i][0].ToString();
            ListItem list = new ListItem(year, year);
            this.ddlYear.Items.Add(list);
        }
    }
    protected void Button2_Click(object sender, EventArgs e)//保存
    {
        bool ret;
        if(SalaryManage.CheckIfExistInfo(Convert.ToInt16( this.ddlID.Text),this.ddlYear.Text,this.ddlMonth.Text))
            ret=SalaryManage.UpdateInfo(Convert.ToInt16( this.ddlID.Text), this.ddlYear.Text, this.ddlMonth.Text, BaseSalary, ResultsWage, AttendanceSalary, OverTimePay, Total);
         else 
            ret=SalaryManage.AddSalaryInfo(Convert.ToInt16( this.ddlID.Text), this.ddlYear.Text, this.ddlMonth.Text, BaseSalary, ResultsWage, AttendanceSalary, OverTimePay, Total);
        if (ret)
        {
            Response.Write("<script lanaguage=javascript>alert('添加员工工资信息成功!')</script>");
        }
        else
        {
            Response.Write("<script lanaguage=javascript>alert('添加失败!')</script>");
        }
    }
    protected void Button3_Click(object sender, EventArgs e)//重置
    {
        this.lbAddUp.Text = "";
        this.lbAttedance.Text = "";
        this.lbJob.Text = "";
        this.lbName.Text = "";
        this.lbOverTimePay.Text = "";
        this.lbResultsWage.Text = "";
        this.lbSalary.Text = "";
    }
}
