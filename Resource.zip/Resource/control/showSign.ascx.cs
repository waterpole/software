﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ResourceManage;

public partial class control_showSign : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["LoginName"]) == "")
        {
            Response.Write("<script language=javascript>alert('请先登录')</script>");
            Response.Redirect("../Default.aspx");
            return;
        }
      
        if (!IsPostBack)
        {
            this.ddlDeptName.DataBind();
        }
    }

      protected void ddlDeptName_DataBinding(object sender, EventArgs e)
    {
        ListItem list = new ListItem("---全部---");
        this.ddlDeptName.Items.Add(list);
        DataView dv = DepartmentManage.GetAllDeptName();
        for (int i = 0; i < dv.Count; i++)
        {
            string deptname = Convert.ToString(dv[i][0]).Trim();
            ListItem list1 = new ListItem(deptname, deptname);
            this.ddlDeptName.Items.Add(list1);
        }
    }

    protected void ddlEmpName_DataBinding(object sender, EventArgs e)
    {
        string deptname = this.ddlDeptName.Text.ToString();
        ListItem list = new ListItem("---全部---");
        this.ddlEmpName.Items.Add(list);
        DataView dv = EmployeeManage.GetEmployeeInfoByDeptname(deptname);
        for (int i = 0; i < dv.Count; i++)
        {
            string empname = Convert.ToString(dv[i][1]).Trim();
            ListItem list1 = new ListItem(empname,empname);
            this.ddlEmpName.Items.Add(list1);
        }
    }

    protected void ddlDeptName_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (this.ddlEmpName.Items.Count > 0)
        {
            this.ddlEmpName.Items.Clear();
        }
        this.ddlEmpName.DataBind();
    }
    protected void btnfind_Click(object sender, EventArgs e)
    {
        if (this.ddlDeptName.Text == "---全部---")
        {
            GridView1.DataSource = SignManage.GetAllSignInfo();
            GridView1.DataBind();
        }
        else if (this.ddlEmpName.Text == "---全部---")
        {
            string deptname = this.ddlDeptName.Text;
            GridView1.DataSource = SignManage.GetAllInSameDept(deptname);
            GridView1.DataBind();
        }
        else
        {
            string name = this.ddlEmpName.Text.ToString();
            string deptname = this.ddlDeptName.Text.ToString();
            GridView1.DataSource = SignManage.GetSignInfoByName(name,deptname);
            GridView1.DataBind();
        }
    }


    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.GridView1.PageIndex = e.NewPageIndex;
    }
}
