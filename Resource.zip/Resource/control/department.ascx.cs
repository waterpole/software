﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ResourceManage;

public partial class control_department : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["LoginName"]) == "")
        {
            Response.Write("<script language=javascript>alert('请先登录')</script>");
            Response.Redirect("../Default.aspx");
            return;
        }

        if (!IsPostBack)
        {
            this.ddlDeptName.DataBind();
        }
    }

    private void dataBind()
    {
        GridView1.DataSource = DepartmentManage.GetAllDeptInfo();
        GridView1.DataBind();
    }
    protected void ddlDeptName_DataBinding(object sender, EventArgs e)
    {
        ListItem list = new ListItem("---全部---");
        this.ddlDeptName.Items.Add(list);
        DataView dv = DepartmentManage.GetAllDeptName();
        for (int i = 0; i < dv.Count; i++)
        {
            string deptname = Convert.ToString(dv[i][0]).Trim();
            ListItem list1 = new ListItem(deptname, deptname);
            this.ddlDeptName.Items.Add(list1);
        }
    }
    protected void Button1_Click(object sender, EventArgs e)//查找按钮
    {
        if (this.ddlDeptName.Text == "---全部---")
        {
            this.GridView1.DataSource = DepartmentManage.GetAllDeptInfo();
            this.GridView1.DataBind();
        }
        else
        {
            string deptname = this.ddlDeptName.Text.ToString().Trim();
            this.GridView1.DataSource = DepartmentManage.GetDeptInfoByName(deptname);
            this.GridView1.DataBind();
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.GridView1.PageIndex = e.NewPageIndex;
        dataBind();
    }

    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        bool ret;
        ret=DepartmentManage.DeleteDeptInfo(Convert.ToInt16( GridView1.DataKeys[e.RowIndex].Value));
        if (ret)
        {
            Response.Write("<script language=javascript>alert('删除部门信息成功!')</script>");
        }
        else
        {
            Response.Write("<script language=javascript>alert('删除失败!')</script>");
        }
        dataBind();
    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        dataBind();
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        bool ret=false;
        Department dept = new Department();
        dept.Dept_ID =Convert.ToInt16( GridView1.DataKeys[e.RowIndex].Value);
        TextBox deptname = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txbDeptName");
        TextBox deptaddr = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txbDeptAddr");
        TextBox depttel = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txbDeptTel");
        TextBox deptmemo = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txbDeptMemo");
        dept.Dept_Name = deptname.Text.Trim().ToString();
        dept.Dept_Addr = deptaddr.Text.Trim().ToString();
        dept.Dept_Tel = depttel.Text.Trim().ToString();
        dept.Dept_Memo = deptmemo.Text.Trim().ToString();
        ret=DepartmentManage.UpdateDeptInfo(dept);
        if (ret)
        {
            Response.Write("<script language=javascript>alert('更新成功!')</script>");
        }
        GridView1.EditIndex = -1;
        dataBind();
    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        dataBind();
    }
}
