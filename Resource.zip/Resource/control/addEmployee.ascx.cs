﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ResourceManage;
using System.IO;

public partial class control_addEmployee : System.Web.UI.UserControl
{
    public static  string path = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["LoginName"]) == "")
        {
            Response.Write("<script language=javascript>alert('请先登录')</script>");
            Response.Redirect("../Default.aspx");
            return;
        }
       
        if (!IsPostBack)
        {
            this.ddlDeptName.DataBind();
            this.ddlJob.DataBind();
        }
    }
    protected void ddlDeptName_DataBinding(object sender, EventArgs e)
    {
        DataView dv = DepartmentManage.GetAllDeptName();
        for (int i = 0; i < dv.Count; i++)
        {
            string deptname=Convert.ToString(dv[i][0]).Trim();
            ListItem list = new ListItem(deptname, deptname);
            this.ddlDeptName.Items.Add(list);
        }
    }
    protected void btnGoUp_Click(object sender, EventArgs e)
    {
        string str = this.FileUpload1.PostedFile.FileName;
        if (str == "")
        {
            Response.Write("<script language=javascript>alert('请选择上传图片!')</script>");
            return;
        }
        string ss = str.Substring(str.LastIndexOf("\\") + 1);
        string s = Server.MapPath("..\\photo\\" + ss);
        path = "..\\photo\\" + ss;//有问题
        if (System.IO.File.Exists(s))
        {
            Response.Write("<script language=javascript>alert('该文件已经存在,请重新命名!!!')</script>");
            return;
        }
        this.FileUpload1.SaveAs(s);
        image.ImageUrl = s;
    }
    protected void update_Click(object sender, EventArgs e)
    {
        Employee emp = new Employee();
        emp.E_ID =0;
        emp.E_Name = this.txbName.Text;
        emp.E_Sex = this.ddlSex.Text;
        emp.E_Birthday = Convert.ToDateTime(this.txbBirthday.Text);
        if (this.ddlMaritalStatus.Text == "1")
        {
            emp.E_MaritalStatus = Convert.ToBoolean(1);
        }
        else emp.E_MaritalStatus = Convert.ToBoolean(0);
        
        emp.E_Learn = this.txbLearn.Text;
        emp.E_Major = this.txbMajor.Text;
        emp.E_PoliticsFace = this.ddlPoliticsFace.Text;
        emp.E_NativePlace=this.txbNativePlace.Text;
        emp.E_Race= this.txbRace.Text;
        emp.E_Address= this.txbAddress.Text;
        emp.E_Post = this.txbPost.Text;
        emp.E_Job = this.ddlJob.Text;
        emp.E_deptID =DepartmentManage.GetDeptIdByName( this.ddlDeptName.Text.Trim());
        //emp.E_Status = Convert.ToBoolean(this.ddlStatus.SelectedValue);
        
        if (this.ddlStatus.Text == "1")
        {
            emp.E_Status = Convert.ToBoolean(1);
        }
        else emp.E_Status = Convert.ToBoolean(0) ;
        
        emp.E_Superior = this.txbSuperior.Text;
        emp.E_MobilePhone = this.txbMobilePhone.Text;
        emp.E_Phone = this.txbPhone.Text;
        emp.E_Email = this.txbEmail.Text;
        emp.E_QQ = this.txbQQ.Text;
        emp.E_MSN = this.txbMSN.Text;
        emp.E_Interest = this.txbInterest.Text;
        emp.E_BeginWorkTime = Convert.ToDateTime(this.txbBeginWorkTime.Text);
        emp.E_IntoCompanyTime = Convert.ToDateTime(this.txbIntoCompanyTime.Text);
        emp.E_RiseSalaryTime = Convert.ToDateTime(this.txbRiseSalaryTime.Text);
        emp.E_IntoDeptTime = Convert.ToDateTime(this.txbIntoDeptTime.Text);
        emp.E_TitleTime = Convert.ToDateTime(this.txbTitleTime.Text);
        emp.E_ExperienceSkill = this.txbExperienceSkill.Text;

       // string str = this.FileUpload1.PostedFile.FileName;
        //string ss = str.Substring(str.LastIndexOf("\\") + 1);
        //string s = Server.MapPath("..\\photo\\" + ss);
       // string path = "..\\photo\\" + ss;
        emp.E_PhotoPath = path;

        emp.E_Remarks = this.txbRemark.Text;
        bool ret = EmployeeManage.AddEmpInfo(emp);
        if (ret)
        {
            Response.Write("<script lanaguage=javascript>alert('添加员工信息成功!')</script>");
        }
        else
        {
            Response.Write("<script lanaguage=javascript>alert('添加员工信息失败!')</script>");
        }

    }
    protected void resert_Click(object sender, EventArgs e)
    {
        this.txbName.Text="";
        this.txbBirthday.Text="";
        this.txbLearn.Text="";
        this.txbMajor.Text="";
        this.txbNativePlace.Text="";
        this.txbRace.Text="";
        this.txbAddress.Text="";
        this.txbPost.Text="";
        this.txbSuperior.Text="";
        this.txbMobilePhone.Text="";
        this.txbPhone.Text="";
        this.txbEmail.Text="";
        this.txbQQ.Text="";
        this.txbMSN.Text="";
        this.txbInterest.Text="";
        this.txbBeginWorkTime.Text="";
        this.txbIntoCompanyTime.Text="";
        this.txbRiseSalaryTime.Text="";
        this.txbIntoDeptTime.Text="";
        this.txbTitleTime.Text="";
        this.txbExperienceSkill.Text="";
        this.txbRemark.Text="";

    }
    protected void ddlJob_DataBinding(object sender, EventArgs e)
    {
        DataView dv = JobSalaryManage.GetAllJob();
        for (int i = 0; i < dv.Count; i++)
        {
            string job = Convert.ToString(dv[i][0]).Trim();
            ListItem list = new ListItem(job, job);
            this.ddlJob.Items.Add(list);
        }
    }
}
