﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ResourceManage;

public partial class control_TotalCheckResult : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["LoginName"]) == "")
        {
            Response.Write("<script language=javascript>alert('请先登录')</script>");
            Response.Redirect("../Default.aspx");
            return;
        }
        
        if (!IsPostBack)
        {
            this.ddlDeptName.DataBind();
        }
    }
    protected void ddlDeptName_DataBinding(object sender, EventArgs e)
    {
        ListItem list = new ListItem("---全部---");
        this.ddlDeptName.Items.Add(list);
        DataView dv = DepartmentManage.GetAllDeptName();
        for (int i = 0; i < dv.Count; i++)
        {
            string deptname = Convert.ToString(dv[i][0]).Trim();
            ListItem list1 = new ListItem(deptname, deptname);
            this.ddlDeptName.Items.Add(list1);
        }
        this.ddlName.DataBind();
    }
   
    protected void ddlName_DataBinding(object sender, EventArgs e)
    {
        ListItem list = new ListItem("---全部---");
        this.ddlName.Items.Add(list);
        DataView dv = EmployeeManage.GetEmpNameByDeptName(this.ddlDeptName.Text);
        for (int i = 0; i < dv.Count; i++)
        {
            string empname = Convert.ToString(dv[i][0]).Trim();
            ListItem list1 = new ListItem(empname,empname);
            this.ddlName.Items.Add(list1);
        }
    }
    protected void find_Click(object sender, EventArgs e)//查找按钮
    {
        if (this.ddlDeptName.Text == "---全部---")
        {
            GridView1.DataSource =CheckResultManage.GetAllCheckResult();
            GridView1.DataBind();
        }
        else if (this.ddlName.Text == "---全部---")
        {
            string deptname = this.ddlDeptName.Text;
            GridView1.DataSource = CheckResultManage.GetCheckResultByDeptName(deptname);
        }
        else
        {
            string deptname = this.ddlDeptName.Text;
            string empname = this.ddlName.Text;
            GridView1.DataSource = CheckResultManage.GetCheckResult(deptname, empname);
            GridView1.DataBind();
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.GridView1.PageIndex = e.NewPageIndex;
    }

    protected void ddlDeptName_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.ddlName.Items.Clear();
        this.ddlName.DataBind();
    }
}
