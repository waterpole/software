﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ResourceManage;

public partial class control_setSystemUser : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["LoginName"]) == "")
        {
            Response.Write("<script language=javascript>alert('请先登录')</script>");
            Response.Redirect("../Default.aspx");
            return;
        }
     
        if (!IsPostBack)
        {
            //装载职员姓名
            dlEmployee.DataSource =EmployeeManage.GetAllEmployeeInfo();
            dlEmployee.DataTextField = "Name";
            dlEmployee.DataValueField = "Name";
            dlEmployee.DataBind();
            //装载系统操作员姓名
            DataTable dt = UserManage.GetAllUserInfo();
            DataRow[] row = dt.Select();
           // DataRow[] row = ds.Tables[0].Select();
            foreach (DataRow rs in row)  //将检索到的数据逐一,循环添加到Listbox1中
            {
                ListBox1.Items.Add(new ListItem(rs["UserName"].ToString()));
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)//
    {
        //判断该系统用户名是否存在,如果存在将不允许创建,否则设置系统用户
        bool ret=UserManage.IfExistUser(this.txbUserName.Text,Convert.ToInt16( this.ddlLevel.SelectedValue));
        if (ret)
        {
            Response.Write("<script language=javascript>alert('该用户已经被设置为系统用户！')</script>");
            return;
        }
        else
        {
            //添加系统用户
            User user = new User();
            user.UserName = this.txbUserName.Text;
            user.UserPwd = this.txbPwd.Text;
            user.LoginTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd"));
            user.UserLevel =Convert.ToInt16( this.ddlLevel.SelectedValue);
            bool i = UserManage.AddUserInfo(user);
            ListBox1.DataBind();
        }
        //Response.Redirect("setSysName.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)//
    {
        //删除系统用户
        UserManage.DeleteUserInfoByName(this.ListBox1.Text);
        string strss = Convert.ToString(Session["LoginName"]);

        if (this.ListBox1.SelectedItem.Text.ToString().Equals(strss))
        {
            //删除当前用户时,退出系统回到首页
            Response.Write("<script language=javascript>parent.location='../Default.aspx'</script>");
        }
        else
        {
            //删除系统操作员后,重新定向到本页
            Response.Redirect("./setSystemUser.aspx");
        }

    }
}
