﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ResourceManage;

public partial class control_editRecruit : System.Web.UI.UserControl
{
    public static int id;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["LoginName"]) == "")
        {
            Response.Write("<script language=javascript>alert('请先登录')</script>");
            Response.Redirect("../Default.aspx");
            return;
        }
        string ID=Request.QueryString["id"].ToString();
        id =Convert.ToInt32( ID.Substring(1, ID.Length - 2));
        if (!IsPostBack)
        {
            
            Recruit recruit = new Recruit();
            recruit = RecruitManage.GetRecruitInfoById(id);
            this.txbCompanyName.Text=recruit.CompanyName ;
            this.txbIntroduction.Text=recruit.Introduction ;
            this.txbPostKeyWord.Text=recruit.PostKeyWord ;
            this.txbRecruitPost.Text=recruit.RecruitPost ;
            this.txbEmail.Text=recruit.Email ;
            this.txbWorkPlace.Text=recruit.WorkPlace ;
            this.txbRecruitNum.Text = recruit.RecruitNum.ToString() ;
            this.txbSalaryScope.Text=recruit.SalaryScope ;
            this.txbLearnRequest.Text = recruit.LearnRequest;
            this.txbWorkTimeLimit.Text=recruit.WorkTimeLimit  ;
            this.txbEnglishRequest.Text= recruit.EnglishRequest  ;
            this.txbPostDescription.Text=recruit.PostDescription  ;
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Recruit recruit = new Recruit();
        recruit.RecruitID = id;
        recruit.CompanyName = this.txbCompanyName.Text;
        recruit.Introduction = this.txbIntroduction.Text;
        recruit.PostKeyWord = this.txbPostKeyWord.Text;
        recruit.RecruitPost = this.txbRecruitPost.Text;
        recruit.Email = this.txbEmail.Text;
        recruit.PublishDate =Convert.ToDateTime( DateTime.Now.ToString("yyyy-MM-dd"));
        recruit.WorkPlace = this.txbWorkPlace.Text;
        recruit.RecruitNum =Convert.ToInt16( this.txbRecruitNum.Text);
        recruit.SalaryScope = this.txbSalaryScope.Text;
        recruit.LearnRequest = this.txbLearnRequest.Text;
        recruit.WorkTimeLimit = this.txbWorkTimeLimit.Text;
        recruit.EnglishRequest = this.txbEnglishRequest.Text;
        recruit.PostDescription = this.txbPostDescription.Text;
        bool ret = RecruitManage.UpdateRecruitInfoById(recruit);
        if (ret)
        {
            Response.Write("<script language=javascript>alert('更新成功!')</script>");
        }
        else
        {
            Response.Write("<script language=javascript>alert('更新失败!')</script>");
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("./recruit.aspx");
    }
}
