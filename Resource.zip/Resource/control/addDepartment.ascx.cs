﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ResourceManage;

public partial class control_addDepartment : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["LoginName"]) == "")
        {
            Response.Write("<script language=javascript>alert('请先登录')</script>");
            Response.Redirect("../Default.aspx");
            return;
        }
        if (!IsPostBack)
        {
        }
     
    }

    protected void add_Click(object sender, EventArgs e)
    {
        bool ret = true;
        Department dept = new Department();
        dept.Dept_ID = 0;
        dept.Dept_Name = txbName.Text.ToString().Trim();
        dept.Dept_Addr = txbAddress.Text.ToString().Trim();
        dept.Dept_Tel = txbTel.Text.ToString().Trim();
        dept.Dept_Memo = txbMemo.Text.ToString();
        ret = DepartmentManage.AddDeptInfo(dept);
        if (ret)
        {
            Response.Write("<script lanaguage=javascript>alert('添加成功!')</script>");
        }
        else
        {
            Response.Write("<script lanaguage=javascript>alert('添加失败!')</script>");
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        txbName.Text = "";
        txbAddress.Text = "";
        txbTel.Text = "";
        txbMemo.Text = "";
    }
}
