﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ResourceManage;

public partial class control_addRecruit : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["LoginName"]) == "")
        {
            Response.Write("<script language=javascript>alert('请先登录')</script>");
            Response.Redirect("../Default.aspx");
            return;
        }
        if (!IsPostBack)
        {
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Recruit recruit = new Recruit();
        recruit.CompanyName = this.txbCompanyName.Text;
        recruit.Introduction = this.txbIntroduction.Text;
        recruit.PostKeyWord = this.txbPostKeyWord.Text;
        recruit.RecruitPost = this.txbRecruitPost.Text;
        recruit.Email = this.txbEmail.Text;
        recruit.PublishDate =Convert.ToDateTime( DateTime.Now.ToString("yyyy-MM-dd"));
        recruit.WorkPlace = this.txbWorkPlace.Text;
        recruit.RecruitNum =Convert.ToInt16( this.txbRecruitNum.Text);
        recruit.SalaryScope = this.txbSalaryScope.Text;
        recruit.LearnRequest = this.txbLearnRequest.Text;
        recruit.WorkTimeLimit = this.txbWorkTimeLimit.Text;
        recruit.EnglishRequest = this.txbEnglishRequest.Text;
        recruit.PostDescription = this.txbPostDescription.Text;
        bool ret = RecruitManage.AddRecruitInfo(recruit);
        if (ret)
        {
            Response.Write("<script language=javascript>alert('发布成功!')</script>");
        }
        else
        {
            Response.Write("<script language=javascript>alert('发布失败!')</script>");
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        this.txbCompanyName.Text="";
        this.txbIntroduction.Text="";
        this.txbPostKeyWord.Text = "";
        this.txbRecruitPost.Text = "";
        this.txbEmail.Text = "";
        this.txbWorkPlace.Text = "";
        this.txbRecruitNum.Text = "";
        this.txbSalaryScope.Text = "";
        this.txbLearnRequest.Text = "";
        this.txbWorkTimeLimit.Text = "";
        this.txbEnglishRequest.Text = "";
        this.txbPostDescription.Text = "";
    }
}
