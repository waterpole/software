﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ResourceManage;

public partial class control_addNews : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["LoginName"]) == "")
        {
            Response.Write("<script language=javascript>alert('请先登录')</script>");
            Response.Redirect("../Default.aspx");
            return;
        }
        if (!IsPostBack)
        {
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        News newslist=new News();
        newslist.NewsTitle =this.txbNewsTitle.Text;
        newslist.NewsContent = this.txbNewsContent.Text;
        newslist.NewsCreateTime = DateTime.Now;
        newslist.NewsPublishDate = DateTime.Now;
        newslist.NewsCreator = this.txbCreator.Text;
        newslist.IfPublish = true;
        newslist.IfAutoPopUp = this.rdbAutoPopup.Checked;
        newslist.ViewCounter = 0;
        bool ret = NewsManage.AddNews(newslist);
        if (ret)
        {
            Response.Write("<script language=javascript>alert('发布成功!')</script>");
        }
        else
        {
            Response.Write("<script language=javascript>alert('发布失败!')</script>");
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        this.txbNewsTitle.Text = "";
        this.txbNewsContent.Text = "";
        this.txbCreator.Text = "";
        this.rdbAutoPopup.Checked = false;
    }
}
