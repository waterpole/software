﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ResourceManage;

public partial class control_receiveFile : System.Web.UI.UserControl
{
    private static int PageSize, CurrentPage, RecordCount, PageCount;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["LoginName"]) == "")
        {
            Response.Write("<script language=javascript>alert('请先登录')</script>");
            Response.Redirect("../Default.aspx");
            return;
        }
        
        if (!IsPostBack)
        {
            PageSize = 5;
            if (!IsPostBack)
            {
                CurrentPage = 0;
                ViewState["PageIndex"] = 0;
                dataBind();
            }
        }
        
    }
    public void dataBind()
    {

        bool tr = true;


        if (this.RadioButton3.Checked)//全部显示按钮
        {
            if (Convert.ToInt32(Session["Level"].ToString()) == 0)
            {
                this.DataList1.DataSource = FileManage.GetFileInfo(CurrentPage, PageSize, "");
                RecordCount = FileManage.GetFileCount("");
            }
            else
            {
                this.DataList1.DataSource = FileManage.GetFileInfo(CurrentPage, PageSize,Session["UserName"].ToString().Trim());
                RecordCount = FileManage.GetFileCount(Session["UserName"].ToString().Trim());
            }
            this.DataList1.DataKeyField = "FileID";
            this.DataList1.DataBind();


            
            PageCount = RecordCount / PageSize;
            if (RecordCount % PageSize != 0)
            {
                PageCount = PageCount + 1;
            }
            ViewState["PageCount"] = PageCount;
        }
        if (this.RadioButton2.Checked)//未接收按钮
        {
            tr = false;
            if (Convert.ToInt32(Session["Level"].ToString()) == 0)
            {
                this.DataList1.DataSource = FileManage.FileGet(tr, CurrentPage, PageSize,"");
                RecordCount = FileManage.GetFileCount(tr,"");
            }
            else
            {
                this.DataList1.DataSource = FileManage.FileGet(tr, CurrentPage, PageSize, Session["UserName"].ToString().Trim());
                RecordCount = FileManage.GetFileCount(tr, Session["UserName"].ToString().Trim());
            }
            this.DataList1.DataKeyField = "FileID";
            this.DataList1.DataBind();

            
            PageCount = RecordCount / PageSize;
            if (RecordCount % PageSize != 0)
            {
                PageCount = PageCount + 1;
            }
            ViewState["PageCount"] = PageCount;


        }
        if (this.RadioButton1.Checked)//已接收按钮
        {
            tr = true;
            if (Convert.ToInt32(Session["Level"].ToString()) == 0)
            {
                this.DataList1.DataSource = FileManage.FileGet(tr, CurrentPage, PageSize, "");
                RecordCount = FileManage.GetFileCount(tr, "");
            }
            else
            {
                this.DataList1.DataSource = FileManage.FileGet(tr, CurrentPage, PageSize, Session["UserName"].ToString().Trim());
                RecordCount = FileManage.GetFileCount(tr, Session["UserName"].ToString().Trim());
            }
            this.DataList1.DataKeyField = "FileID";
            this.DataList1.DataBind();

            
            PageCount = RecordCount / PageSize;
            if (RecordCount % PageSize != 0)
            {
                PageCount = PageCount + 1;
            }
            ViewState["PageCount"] = PageCount;

        }
        lkbNextPage.Enabled = true;
        lkbPrevPage.Enabled = true;
        if (CurrentPage == 0)
        {
            lkbPrevPage.Enabled = false;
        }
        if (CurrentPage == (PageCount - 1))
        {
            lkbNextPage.Enabled = false;
        }

    }
    protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
    {
        //点击查看按钮
        if (e.CommandName == "View")

        //显示选择模版中的内容
        {
            DataList1.SelectedIndex = e.Item.ItemIndex;
            int fileId;
            fileId =Convert.ToInt32( DataList1.DataKeys[e.Item.ItemIndex].ToString());

            this.DataList1.DataSource = FileManage.GetFileByFileId(fileId);
            this.DataList1.DataBind();
            FileManage.UpdateAccepteStatus(fileId);
        }
        if (e.CommandName == "Cancel")
        {

            DataList1.SelectedIndex = -1;
            DataList1.EditItemIndex = -1;
            dataBind();

        }

    }

    protected void DataList1_DeleteCommand(object source, DataListCommandEventArgs e)
    {
        int file_ID;
        file_ID = Convert.ToInt32(DataList1.DataKeys[e.Item.ItemIndex].ToString());
        try
        {
            FileManage.DeleteFileByFileId(file_ID);
        }
        catch (Exception ee)
        {
            string msg = ee.Message;
        }
        finally
        {
            dataBind();

        }
    }

    protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
    {
        dataBind();
    }
    protected void RadioButton2_CheckedChanged(object sender, EventArgs e)
    {
        dataBind();
    }
    protected void RadioButton3_CheckedChanged(object sender, EventArgs e)
    {
        dataBind();
    }
    protected void Page_Command(object sender, CommandEventArgs e)
    {
        CurrentPage = (int)ViewState["PageIndex"];
        PageCount = (int)ViewState["PageCount"];
        string ce = e.CommandName;//判断翻页方向
        switch (ce)
        {
            case "Prev":
                if (CurrentPage > 0) CurrentPage--;
                break;
            case "Next":
                if (CurrentPage < (PageCount - 1)) CurrentPage++;
                break;
        }
        ViewState["PageIndex"] = CurrentPage;
        dataBind();
    }
    
 
}
