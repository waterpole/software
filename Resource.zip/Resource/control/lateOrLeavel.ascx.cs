﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ResourceManage;
using System.Timers;

public partial class control_lateOrLeavel : System.Web.UI.UserControl
{
    static string up1;//上午上班时间
    static string up2;//上午下班时间
    static string down1;//下午上班时间
    static string down2;//下午下班时间

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["LoginName"]) == "")
        {
            Response.Write("<script language=javascript>alert('请先登录')</script>");
            Response.Redirect("../Default.aspx");
            return;
        }
        
        if (!IsPostBack)
        {
            databind();
        }
    }

    public void databind()
    {
        DataSet ds = new DataSet();
        ds = SignstateManage.GetAllInfo();
        DataRow[] row1 = ds.Tables[0].Select("SignStateID=1");
        foreach (DataRow rs in row1)
        {
            this.lb1.Text="上午上班时间:"+ Convert.ToDateTime(rs["Time"]).ToString("HH:mm:ss");
            up1 = Convert.ToDateTime(rs["Time"]).ToString("HH:mm:ss");
        }
        DataRow[] row2 = ds.Tables[0].Select("SignStateID=2");
        foreach (DataRow rs in row2)
        {
            this.lb2.Text ="上午下班时间"+ Convert.ToDateTime(rs["Time"]).ToString("HH:mm:ss");
            up2 = Convert.ToDateTime(rs["Time"]).ToString("HH:mm:ss");
        }
        DataRow[] row3 = ds.Tables[0].Select("SignStateID=3");
        foreach (DataRow rs in row3)
        {
            this.lb3.Text="下午上班时间"+ Convert.ToDateTime(rs["Time"]).ToString("HH:mm:ss");
            down1 = Convert.ToDateTime(rs["Time"]).ToString("HH:mm:ss");
        }
        DataRow[] row4 = ds.Tables[0].Select("SignStateID=4");
        foreach (DataRow rs in row4)
        {
            this.lb4.Text="下午下班时间"+ Convert.ToDateTime(rs["Time"]).ToString("HH:mm:ss");
            down2 = Convert.ToDateTime(rs["Time"]).ToString("HH:mm:ss");
        }
        lbsign1.Text = DateTime.Now.ToString("HH:mm:ss");
        lbsign2.Text = DateTime.Now.ToString("HH:mm:ss");
        lbsign3.Text = DateTime.Now.ToString("HH:mm:ss");
        lbsign4.Text = DateTime.Now.ToString("HH:mm:ss");

        TimeSpan ts = Convert.ToDateTime(DateTime.Now.ToString("hh:mm:ss")) - Convert.ToDateTime(up2);
        int i = ts.Hours;
        if (DateTime.Now.Hour<=Convert.ToDateTime(up2).Hour)
        {
            // lbsign1.Visible = true;
            // lbsign2.Visible = true;
            Button1.Visible = true;
            Button2.Visible = true;

            // lbsign3.Visible = false;
            // lbsign4.Visible = false;
            Button3.Visible = false;
            Button4.Visible = false;
        }
        else
        {
            // lbsign1.Visible = false;
            // lbsign2.Visible = false;
            Button1.Visible = false;
            Button2.Visible = false;


            // lbsign3.Visible = true ;
            // lbsign4.Visible = true;
            Button3.Visible = true;
            Button4.Visible = true;
        }
    }

    protected void Button1_Click(object sender, EventArgs e)//上午上班签到按钮
    {//上午上班进行考勤设置
        DateTime signtime =Convert.ToDateTime( DateTime.Now.ToString("hh:mm:ss"));
        string signname =(string) Session["LoginName"];
        int  empid =Convert.ToInt16( Session["LoginID"].ToString());
        if (DateTime.Now.Hour <= Convert.ToDateTime(up1).Hour)
        {
            bool iflate = false;
            bool ifquit = false;
            int overtime = 0;
            SignManage.AddSignInfo(signtime, iflate, ifquit, overtime, empid);
        }
        else
        {
            bool iflate = true;
            bool ifquit = false;
            int overtime = 0;
            SignManage.AddSignInfo(signtime, iflate, ifquit, overtime, empid);
        }
    }
    protected void Button2_Click(object sender, EventArgs e)//上午下班签退按钮
    {//上午下班进行考勤设置
        DateTime signtime = Convert.ToDateTime(DateTime.Now.ToString("hh:mm:ss"));
        string signname = (string)Session["LoginName"];
        int  empid =Convert.ToInt16( Session["LoginID"].ToString());
        if (DateTime.Now.Hour >= Convert.ToDateTime(up2).Hour)
        {
            bool iflate = false;
            bool ifquit = false;
            //TimeSpan ts = Convert.ToDateTime(up2) - Convert.ToDateTime(DateTime.Now.ToString("hh:mm:ss"));
            int overtime =Convert.ToInt16(DateTime.Now.Hour- Convert.ToDateTime(up2).Hour);
            SignManage.AddSignInfo(signtime, iflate, ifquit, overtime, empid);
        }
        else
        {

            bool iflate = false;
            bool ifquit = true;

            int overtime = 0;

            SignManage.AddSignInfo(signtime, iflate, ifquit, overtime, empid);
        }
    }
    protected void Button3_Click(object sender, EventArgs e)//下午上班签到按钮
    {//下午上班进行考勤设置
        DateTime signtime = DateTime.Now;
        string signname = (string)Session["LoginName"];
        int empid =Convert.ToInt16( Session["LoginID"].ToString());

        if (DateTime.Now.Hour <= Convert.ToDateTime(down1).Hour)
        {
            bool iflate = false;
            bool ifquit = false;
            int overtime = 0;
            SignManage.AddSignInfo(signtime, iflate, ifquit, overtime, empid);
        }
        else
        {
            bool iflate = true;
            bool ifquit = false;
            int overtime = 0;
            SignManage.AddSignInfo(signtime, iflate, ifquit, overtime, empid);
        }
    }
    protected void Button4_Click(object sender, EventArgs e)//下午下班签退按钮
    {//下午下班进行考勤设置
        DateTime signtime = DateTime.Now;
        string signname = (string)Session["LoginName"];
        int empid = Convert.ToInt16(Session["LoginID"].ToString());
        if (DateTime.Now.Hour >= Convert.ToDateTime(down2).Hour)
        {
            bool iflate = false;
            bool ifquit = false;
            int overtime =Convert.ToInt16(DateTime.Now.Hour - Convert.ToDateTime(down2).Hour);
            SignManage.AddSignInfo(signtime, iflate, ifquit, overtime, empid);
        }
        else
        {
            bool iflate = false;
            bool ifquit = true;

            int overtime = 0;

            SignManage.AddSignInfo(signtime, iflate, ifquit, overtime, empid);
        }
    }
}
