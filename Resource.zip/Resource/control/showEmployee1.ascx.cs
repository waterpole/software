﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ResourceManage;

public partial class control_showEmployee1 : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["LoginName"]) == "")
        {
            Response.Write("<script language=javascript>alert('请先登录')</script>");
            Response.Redirect("../Default.aspx");
            return;
        }
       
        if (!IsPostBack)
        {

            Employee emp = EmployeeManage.GetEmpInfoByIdView(Convert.ToInt16( Session["LoginID"].ToString()));
            lbEmpID.Text = emp.E_ID.ToString();
            lbEmpName.Text= emp.E_Name;
            lbSex.Text = emp.E_Sex;
            lbBirthday.Text= emp.E_Birthday.ToString("yyyy-MM-dd");
            if (emp.E_MaritalStatus.Equals(true))
            {
                this.lbMS.Text = "已婚";
            }
            else this.lbMS.Text= "未婚";
            lbLearn.Text = emp.E_Learn;
            lbMajor.Text= emp.E_Major;
            this.lbPF.Text = emp.E_PoliticsFace;
            lbNP.Text= emp.E_NativePlace;
            lbRace.Text= emp.E_Race;
            lbAddress.Text= emp.E_Address;
            lbPost.Text= emp.E_Post;
            this.lbJob.Text= emp.E_Job;
            this.lbDeptName.Text = DepartmentManage.GetDeptNameById(Convert.ToInt16(Session["LoginID"].ToString()));
            if (Convert.ToBoolean(emp.E_Status))
            {
                this.lbStatus.Text = "在职";
            }
            else this.lbStatus.Text = "离职";
            lbSuperior.Text = emp.E_Superior;
            lbMP.Text= emp.E_MobilePhone;
            lbPhone.Text= emp.E_Phone;
            lbEmail.Text = emp.E_Email;
            lbQQ.Text= emp.E_QQ;
            lbMSN.Text= emp.E_MSN;
            lbInterest.Text= emp.E_Interest;
            lbBWT.Text = emp.E_BeginWorkTime.ToString("yyyy-MM-dd");
            lbICT.Text = emp.E_IntoCompanyTime.ToString("yyyy-MM-dd");
            lbRST.Text = emp.E_RiseSalaryTime.ToString("yyyy-MM-dd");
            lbIDT.Text = emp.E_IntoDeptTime.ToString("yyyy-MM-dd");
            lbTT.Text = emp.E_TitleTime.ToString("yyyy-MM-dd");
            lbExperience.Text= emp.E_ExperienceSkill;
            image.ImageUrl = emp.E_PhotoPath;
            lbPath.Text = emp.E_PhotoPath;
            lbRemarks.Text= emp.E_Remarks;
        }
    }
}
