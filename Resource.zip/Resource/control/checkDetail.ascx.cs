﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ResourceManage;

public partial class control_checkDetail : System.Web.UI.UserControl
{
    public static int Empid;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["LoginName"]) == "")
        {
            Response.Write("<script language=javascript>alert('请先登录')</script>");
            Response.Redirect("../Default.aspx");
            return;
        }
       
        if (!IsPostBack)
        {
            string id = Request.QueryString["id"].ToString();
            Empid = Convert.ToInt32(id.Substring(1, id.Length-2));
            DataView dv = EmployeeManage.GetSomeInfoById(Empid);
            this.lbName.Text = dv[0][0].ToString();
            this.lbJob.Text = dv[0][1].ToString();
            this.lbDeptName.Text= dv[0][2].ToString();
            databind();
        }
    }

    protected void databind()
    {
        GridView1.DataSource = CheckItemManage.GetAllItemInfo();
        GridView1.DataBind();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        CheckResult result=new CheckResult ();
        result.EmployeeID = Convert.ToInt16(Session["LoginID"].ToString());
        result.EmployeeIdChecked =Empid;
        bool ret=true ;
        int count = this.GridView1.Rows.Count;
        for (int i = 0; i < count; i++)
        {
            Label weight = (Label)this.GridView1.Rows[i].FindControl("lbWeight");
            RadioButton rb1 = (RadioButton)this.GridView1.Rows[i].FindControl("rb1");
            RadioButton rb2 = (RadioButton)this.GridView1.Rows[i].FindControl("rb2");
            RadioButton rb3 = (RadioButton)this.GridView1.Rows[i].FindControl("rb3");
            RadioButton rb4 = (RadioButton)this.GridView1.Rows[i].FindControl("rb4");
            if(rb1.Checked)
            {
                result.Grade =Convert.ToInt16( Convert.ToInt16(weight.Text) * 0.9);
            }
            else if (rb2.Checked)
            {
                 result.Grade =Convert.ToInt16( Convert.ToInt16(weight.Text) * 0.8);
            }
            else if (rb3.Checked)
            {
                result.Grade  =Convert.ToInt16( Convert.ToInt16(weight.Text) * 0.6);
            }
            else if (rb4.Checked)
            {
                result.Grade =Convert.ToInt16( Convert.ToInt16(weight.Text) * 0.3);
            }
            else
            {
                result.Grade =0;
            }
            result.ItemID =Convert.ToInt16( this.GridView1.DataKeys[i].Value);
            bool ret1 = CheckResultManage.InsertCheckInfo(result);
            ret =ret && ret1;
        }
         Comment cmt = new Comment();
         cmt.Content = this.txbComment.Text;
         cmt.EmployeeID = Convert.ToInt16(Session["LoginID"].ToString());
         cmt.EmployeeIdChecked =Empid;
         bool ret2 = CommentManage.InsertCommentInfo(cmt);
         if (ret && ret2)
         {
             Response.Write("<script language=javascript>alert('保存成功!')</script>");
         }
         else
         {
             Response.Write("<script language=javascript>alert('保存操作失败!')</script>");
         }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("./check.aspx");
    }   
}
