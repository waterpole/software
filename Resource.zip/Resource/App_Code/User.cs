﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace ResourceManage
{
  
    /// <summary>
    /// user 的摘要说明
    /// </summary>
    public class User
    {
        #region  定义私有成员变量

        private int   userID;//登陆用户ID
        private string userName;//用户姓名
        private string userPwd;//用户密码
        private DateTime loginTime;//登陆时间
        private int userLevel;//用户级别

        #endregion

        #region 变量属性

        public int  UserID
        {
            get
            {
                return userID;
            }
            set
            {
                userID = value;
            }
        }
        public string UserName
        {
            get
            {
                return userName;
            }
            set
            {
                userName = value;
            }
        }
        public string UserPwd
        {
            get
            {
                return userPwd;
            }
            set
            {
                userPwd = value;
            }
        }
        public DateTime LoginTime
        {
            get
            {
                return loginTime;
            }
            set
            {
                loginTime = value;
            }
        }
        public int UserLevel
        {
            get
            {
                return userLevel;
            }
            set
            {
                userLevel = value;
            }
        }
       
        #endregion
        public User()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
        }
    }
}
