﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace ResourceManage
{
    /// <summary>
    /// SignstateManage 的摘要说明
    /// </summary>
    public class SignstateManage
    {
        public static SqlConnection myconn;
        static  SignstateManage()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
            myconn = new SqlConnection();
            myconn.ConnectionString = ConfigurationManager.AppSettings["ConnectionString"];
            myconn.Open();
        }
        ~SignstateManage()
        {
            myconn.Close();
        }

        #region
        /// <summary>
        /// 修改员工上下班时间
        /// </summary>
        /// <param name="id">签到时间描述ID</param>
        /// <param name="time">规定的签到时间</param>
        /// <returns>修改信息是否成功的标志</returns>
        public static bool UpdateInfo(int id, DateTime time)
        {
            bool ret = true;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update tb_signstate set Time=@time where SignStateID=@id";
            cmd.Parameters.Add("@time", SqlDbType.DateTime).Value = time;
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
                ret = false;
            }
            return ret;
        }
        #endregion

        #region
        /// <summary>
        /// 查找所有上下班时间设定的信息
        /// </summary>
        /// <returns>数据信息</returns>
        public static DataSet GetAllInfo()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from tb_signstate ";
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
                sda.Fill(ds);
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return ds;
        }
        #endregion 
    }
}
