﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace ResourceManage
{
    /// <summary>
    /// sign 的摘要说明
    /// </summary>
    public class Sign
    {
        #region 定义私有成员变量

        private int signID;//签到表ID
        private DateTime signTime;//签到时间
        private bool ifLate;//是否迟到
        private bool ifQuit;//是否早退
        private int  overTime;//加班时间
        private int e_ID;//员工ID

        #endregion

        #region 定义属性

        public int SignID
        {
            get
            {
                return signID;
            }
            set
            {
                signID = value;
            }
        }
        public DateTime SignTime
        {
            get
            {
                return signTime;
            }
            set
            {
                signTime = value;
            }
        }
 
        public bool IfLate
        {
            get
            {
                return ifLate;
            }
            set
            {
                ifLate = value;
            }
        }
        public bool IfQuit
        {
            get
            {
                return ifQuit;
            }
            set
            {
                ifQuit = value;
            }
        }
        public int OverTime
        {
            get
            {
                return overTime;
            }
            set
            {
                overTime  = value;
            }
        }
      
        public int E_ID
        {
            get
            {
                return e_ID;
            }
            set
            {
                e_ID = value;
            }
        }
        #endregion
        public Sign()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
        }
    }
}
