﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace ResourceManage
{
    /// <summary>
    /// RecruitManage 的摘要说明
    /// </summary>
    public class RecruitManage
    {
        public static SqlConnection myconn;
        static RecruitManage()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
            myconn = new SqlConnection();
            myconn.ConnectionString = ConfigurationManager.AppSettings["ConnectionString"];
            myconn.Open();
        }
        ~RecruitManage()
        {
            myconn.Close();
        }

        #region
        /// <summary>
        /// 查找所有招聘信息
        /// </summary>
        /// <returns>招聘信息表</returns>
        public static DataTable GetAllRecruitInfo()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from tb_recruit order by PubDate desc";
            cmd.Connection = myconn;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dt.Clear();
            try
            {
                cmd.ExecuteNonQuery();
                sda.Fill(dt);
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dt;
        }
        #endregion

        #region
        /// <summary>
        /// 根据招聘ID删除招聘信息
        /// </summary>
        /// <param name="id">招聘ID</param>
        /// <returns>返回删除操作是否成功的标志</returns>
        public static bool DeleteRecruitInfo(int id)
        {
            bool ret = true;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from tb_recruit where RecruitID=@id";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
                ret = false;
            }
            return ret ;
        }
        #endregion

        #region
        /// <summary>
        /// 根据招聘ID号查找招聘信息
        /// </summary>
        /// <param name="id">招聘ID号</param>
        /// <returns>返回招聘信息类</returns>
        public static Recruit GetRecruitInfoById(int id)
        {
            Recruit recruit = new Recruit();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from tb_recruit where RecruitID=@id";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
            cmd.Connection = myconn;
            try
            {
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    recruit.CompanyName = sdr.GetString(1);
                    recruit.Introduction = sdr.GetString(2);
                    recruit.PostKeyWord = sdr.GetString(3);
                    recruit.RecruitPost = sdr.GetString(4);
                    recruit.Email= sdr.GetString(5);
                    recruit.PublishDate = sdr.GetDateTime(6);
                    recruit.WorkPlace= sdr.GetString(7);
                    recruit.RecruitNum = sdr.GetInt32(8);
                    recruit.SalaryScope = sdr.GetString(9);
                    recruit.LearnRequest = sdr.GetString(10);
                    recruit.WorkTimeLimit = sdr.GetString(11);
                    recruit.EnglishRequest = sdr.GetString(12);
                    recruit.PostDescription = sdr.GetString(13);
                }
                sdr.Close();
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return recruit;
        }
        #endregion

        #region
        /// <summary>
        /// 添加招聘信息
        /// </summary>
        /// <param name="recruit">招聘信息类</param>
        /// <returns>返回添加操作是否成功的标志</returns>
        public static bool AddRecruitInfo(Recruit recruit)
        {
            bool ret=true ;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into tb_recruit(CompanyName,Introduction,PostKeyWord,RecruitPost,email,PubDate,WorkPlace,RecruitNum,SalaryScope,LearnRequest,WorkTimeLimit,EnglishRequest,PostDescription) values(@name,@introduction,@keyword,@post,@email,@pubdate,@place,@num,@salary,@learn,@worktime,@english,@postdescription)";
            cmd.Parameters.Add("@name",SqlDbType.VarChar,50).Value=recruit.CompanyName;
            cmd.Parameters.Add("@introduction",SqlDbType.Text).Value=recruit.Introduction;
            cmd.Parameters.Add("@keyword",SqlDbType.VarChar,20).Value=recruit.PostKeyWord;
            cmd.Parameters.Add("@post",SqlDbType.VarChar,100).Value= recruit.RecruitPost;
            cmd.Parameters.Add("@email",SqlDbType.VarChar,20).Value=recruit.Email;
            cmd.Parameters.Add("@pubdate",SqlDbType.DateTime).Value=recruit.PublishDate;
            cmd.Parameters.Add("@place",SqlDbType.VarChar,50).Value=recruit.WorkPlace;
            cmd.Parameters.Add("@num",SqlDbType.Int).Value=recruit.RecruitNum;
            cmd.Parameters.Add("@salary",SqlDbType.VarChar,20).Value=recruit.SalaryScope;
            cmd.Parameters.Add("@learn",SqlDbType.VarChar,20).Value=recruit.LearnRequest;
            cmd.Parameters.Add("@worktime",SqlDbType.VarChar,20).Value=recruit.WorkTimeLimit;
            cmd.Parameters.Add("@english",SqlDbType.VarChar,20).Value=recruit.EnglishRequest;
            cmd.Parameters.Add("@postdescription",SqlDbType.Text).Value=recruit.PostDescription;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
                ret=false;
            }
            return ret;
        }
        #endregion

        #region
        /// <summary>
        /// 更新招聘信息
        /// </summary>
        /// <param name="recruit">招聘信息类</param>
        /// <returns>返回更新操作是否成功的标志</returns>
        public static bool UpdateRecruitInfoById(Recruit recruit)
        {
            bool ret = true;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update tb_recruit set CompanyName=@name,Introduction=@introduction,PostKeyWord=@keyword,RecruitPost=@post,email=@email,PubDate=@pubdate,WorkPlace=@place,RecruitNum=@num,SalaryScope=@salary,LearnRequest=@learn,WorkTimeLimit=@worktime,EnglishRequest=@english,PostDescription=@postdescription where RecruitID=@id";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = recruit.RecruitID;                                                                                                                                        
            cmd.Parameters.Add("@name", SqlDbType.VarChar, 50).Value = recruit.CompanyName;
            cmd.Parameters.Add("@introduction", SqlDbType.Text).Value = recruit.Introduction;
            cmd.Parameters.Add("@keyword", SqlDbType.VarChar, 20).Value = recruit.PostKeyWord;
            cmd.Parameters.Add("@post", SqlDbType.VarChar, 100).Value = recruit.RecruitPost;
            cmd.Parameters.Add("@email", SqlDbType.VarChar, 20).Value = recruit.Email;
            cmd.Parameters.Add("@pubdate", SqlDbType.DateTime).Value = recruit.PublishDate;
            cmd.Parameters.Add("@place", SqlDbType.VarChar, 50).Value = recruit.WorkPlace;
            cmd.Parameters.Add("@num", SqlDbType.Int).Value = recruit.RecruitNum;
            cmd.Parameters.Add("@salary", SqlDbType.VarChar, 20).Value = recruit.SalaryScope;
            cmd.Parameters.Add("@learn", SqlDbType.VarChar, 20).Value = recruit.LearnRequest;
            cmd.Parameters.Add("@worktime", SqlDbType.VarChar, 20).Value = recruit.WorkTimeLimit;
            cmd.Parameters.Add("@english", SqlDbType.VarChar, 20).Value = recruit.EnglishRequest;
            cmd.Parameters.Add("@postdescription", SqlDbType.Text).Value = recruit.PostDescription;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
                ret = false;
            }
            return ret;
        }
        #endregion
    }
}
