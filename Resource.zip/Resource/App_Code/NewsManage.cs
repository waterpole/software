﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace ResourceManage
{
    /// <summary>
    /// NewsManage 的摘要说明
    /// </summary>
    public class NewsManage
    {
        public static SqlConnection myconn;
        static NewsManage()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
            myconn = new SqlConnection();
            myconn.ConnectionString = ConfigurationManager.AppSettings["ConnectionString"];
            myconn.Open();
        }
        ~NewsManage()
        {
            myconn.Close();
        }

        #region
        /// <summary>
        /// 查找所有新闻信息
        /// </summary>
        /// <returns>新闻信息表</returns>
        public static DataTable GetAllNewsInfo()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from tb_news where IfPublish=1 order by PublishDate desc";
            cmd.Connection = myconn;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dt.Clear();
            try
            {
                cmd.ExecuteNonQuery();
                sda.Fill(dt);
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dt;
        }
        #endregion

        #region
        /// <summary>
        /// 删除新闻信息
        /// </summary>
        /// <param name="newsid">新闻ID</param>
        /// <returns>返回是否成功的标志</returns>
        public static bool DeleteNews(int newsid)
        {
            bool ret = true;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from tb_news where NewsID=@newsid";
            cmd.Parameters.Add("@newsid", SqlDbType.Int).Value = newsid;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
                ret = false;
            }
            return ret;
        }
        #endregion

        #region
        /// <summary>
        /// 根据新闻ID号查找新闻信息
        /// </summary>
        /// <param name="newsid">新闻ID号</param>
        /// <returns>返回新闻信息</returns>
        public static News GetNewsById(int newsid)
        {
            News newslist = new News();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from  tb_news where NewsID=@newsid";
            cmd.Parameters.Add("@newsid", SqlDbType.Int).Value = newsid;
            cmd.Connection = myconn;
            try
            {
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    newslist.NewsID = newsid;
                    newslist.NewsTitle = sdr.GetString(1);
                    newslist.NewsContent = sdr.GetString(2);
                    newslist.NewsCreateTime = sdr.GetDateTime(3);
                    newslist.NewsPublishDate = sdr.GetDateTime(4);
                    newslist.NewsCreator = sdr.GetString(5);
                    newslist.IfPublish = sdr.GetBoolean(6);
                    newslist.IfAutoPopUp = sdr.GetBoolean(7);
                    newslist.ViewCounter = sdr.GetInt32(8);
                }
                sdr.Close();
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return newslist;

        }
        #endregion

        #region
        /// <summary>
        /// 更新查看新闻的人数
        /// </summary>
        /// <param name="newsid">新闻ID号</param>
        public static void UpdateViewCounter(int newsid)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update  tb_news set ViewCounter=ViewCounter+1 where NewsID=@newsid and IfPublish=1";
            cmd.Parameters.Add("@newsid", SqlDbType.Int).Value = newsid;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }

        }
        #endregion

        #region
        /// <summary>
        /// 添加新闻信息
        /// </summary>
        /// <param name="newslist">新闻信息类</param>
        /// <returns>返回添加信息是否成功的标志</returns>
        public static bool AddNews(News newslist)
        {
            bool ret = true;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into tb_news(Title,Content,CreatTime,PublishDate,Creator,Ifpublish,IfAutoPopUp,ViewCounter) values(@title,@content,@creattime,@publishtime,@creator,@ifpublish,@ifautopopup,@viewcounter)";
            cmd.Parameters.Add("@title", SqlDbType.VarChar, 100).Value = newslist.NewsTitle;
            cmd.Parameters.Add("@content", SqlDbType.Text).Value = newslist.NewsContent;
            cmd.Parameters.Add("@creattime", SqlDbType.DateTime).Value = newslist.NewsCreateTime;
            cmd.Parameters.Add("@publishtime", SqlDbType.DateTime).Value = newslist.NewsPublishDate;
            cmd.Parameters.Add("@creator", SqlDbType.VarChar, 20).Value = newslist.NewsCreator;
            cmd.Parameters.Add("@ifpublish", SqlDbType.Bit).Value = newslist.IfPublish;
            cmd.Parameters.Add("@ifautopopup", SqlDbType.Bit).Value = newslist.IfAutoPopUp;
            cmd.Parameters.Add("@viewcounter", SqlDbType.Int).Value = newslist.ViewCounter;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
                ret = false;
            }
            return ret;
        }
        #endregion
    }

}
