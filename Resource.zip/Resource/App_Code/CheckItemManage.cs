﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace ResourceManage
{
    /// <summary>
    /// CheckItemManage 的摘要说明
    /// </summary>
    public class CheckItemManage
    {
        public static SqlConnection myconn;
        static  CheckItemManage()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
            myconn = new SqlConnection();
            myconn.ConnectionString = ConfigurationManager.AppSettings["ConnectionString"];
            myconn.Open();
        }
        ~CheckItemManage()
        {
            myconn.Close();
        }

        #region 添加考核指标项
        /// <summary>
        /// 添加考核指标项
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public static bool AddItemInfo(CheckItem item)
        {
            bool ret = true;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into tb_checkItem(ItemContent,ItemDescript,ItemWeight) values(@content,@descript,@weight)";
            cmd.Parameters.Add("@content", SqlDbType.VarChar, 50).Value = item.ItemContent;
            cmd.Parameters.Add("@descript", SqlDbType.VarChar, 200).Value = item.ItemDescript;
            cmd.Parameters.Add("@weight", SqlDbType.TinyInt).Value = item.ItemWeight;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
                ret = false;
            }
            return ret;
        }
        #endregion

        #region 查找所有考核指标信息
        /// <summary>
        /// 查找所有考核指标信息
        /// </summary>
        /// <returns></returns>
        public static DataTable GetAllItemInfo()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from tb_checkItem order by ItemID";
            cmd.Connection = myconn;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dt.Clear();
            try
            {
                cmd.ExecuteNonQuery();
                sda.Fill(dt);
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dt;
        }
        #endregion

        #region 根据项目编号删除其信息
        /// <summary>
        /// 根据项目编号删除其信息
        /// </summary>
        /// <param name="id">项目编号</param>
        /// <returns></returns>
        public static bool DeleteItemInfoById(int id)
        {
            bool ret = true;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from tb_checkItem where ItemID=@id";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return ret;
        }
        #endregion

        #region 更新考核指标信息
        /// <summary>
        /// 更新考核指标信息
        /// </summary>
        /// <param name="item"></param>
        public static void UpdateInfo(CheckItem item)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update tb_checkItem set ItemContent=@content,ItemDescript=@descript,ItemWeight=@weight where ItemID=@id";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = item.ItemID;
            cmd.Parameters.Add("@content", SqlDbType.VarChar, 50).Value = item.ItemContent;
            cmd.Parameters.Add("@descript", SqlDbType.VarChar, 200).Value = item.ItemDescript;
            cmd.Parameters.Add("@weight", SqlDbType.TinyInt).Value = item.ItemWeight;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
        }
        #endregion
    }
}
