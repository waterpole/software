﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace ResourceManage
{
    /// <summary>
    /// File 的摘要说明
    /// </summary>
    public class File
    {
        #region 定义私有成员变量

        private int fileID;//文件ID
        private string fileSender;//文件发送者
        private string fileAccepter;//文件接收者
        private string fileTitle;//文件标题
        private DateTime fileTime;//文件发送时间
        private string fileContent;//文件内容
        private string filePath;//文件路径
        private string fileName;//文件名
        private bool ifReceive;//是否接收

        #endregion

        #region  定义变量属性


        public int FileID
        {
            get
            {
                return fileID;
            }
            set
            {
                fileID = value;
            }
        }
        public string FileSender
        {
            get
            {
                return fileSender;
            }
            set
            {
                fileSender = value;
            }
        }
        public string FileAccepter
        {
            get
            {
                return fileAccepter;
            }
            set
            {
                fileAccepter = value;
            }
        }
        public string FileTitle
        {
            get
            {
                return fileTitle;
            }
            set
            {
                fileTitle = value;
            }
        }
        public DateTime FileTime
        {
            get
            {
                return fileTime;
            }
            set
            {
                fileTime = value;
            }
        }
        public string FileContent
        {
            get
            {
                return fileContent;
            }
            set
            {
                fileContent = value;
            }
        }
        public string FilePath
        {
            get
            {
                return filePath;
            }
            set
            {
                filePath = value;
            }
        }
        public string FileName
        {
            get
            {
                return fileName;
            }
            set
            {
                fileName = value;
            }
        }
        public bool IfReceive
        {
            get
            {
                return ifReceive;
            }
            set
            {
                ifReceive = value;
            }
        }

        #endregion
        public File()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
        }
    }
}
