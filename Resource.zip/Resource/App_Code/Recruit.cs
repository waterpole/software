﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace ResourceManage
{
    /// <summary>
    /// Recruit 的摘要说明
    /// </summary>
    public class Recruit
    {
        #region  定义私有成员变量

        private int recruitID;//招聘ID
        private string companyName;//公司名称
        private string introduction;//公司简介
        private string postKeyWord;//职位搜索关键字
        private string recruitPost;//招聘职位
        private string email;//公司邮箱
        private DateTime publishDate;//发布时间
        private string workPlace;//工作地点
        private int recruitNum;//招聘人数
        private string salaryScope;//薪水范围
        private string  learnRequest;//学历要求
        private string workTimeLimit;//工作年限
        private string englishRequest;//外语要求
        private string postDescription;//职位描述

        #endregion

        #region  定义变量属性

        public int RecruitID
        {
            get
            {
                return recruitID;
            }
            set
            {
                recruitID = value;
            }
        }
        public string CompanyName
        {
            get
            {
                return companyName;
            }
            set
            {
                companyName = value;
            }
        }
        public string Introduction
        {
            get
            {
                return introduction;
            }
            set
            {
                introduction = value;
            }
        }
        public string PostKeyWord
        {
            get
            {
                return postKeyWord;
            }
            set
            {
                postKeyWord = value;
            }
        }
        public string RecruitPost
        {
            get
            {
                return recruitPost;
            }
            set
            {
                recruitPost = value;
            }
        }
        public string Email
        {
            get
            {
                return email;
            }
            set
            {
                email = value;
            }
        }
        public DateTime PublishDate
        {
            get
            {
                return publishDate;
            }
            set
            {
                publishDate = value;
            }
        }
        public string WorkPlace
        {
            get
            {
                return workPlace;
            }
            set
            {
                workPlace = value;
            }
        }
        public int RecruitNum
        {
            get
            {
                return recruitNum;

            }
            set
            {
                recruitNum = value;
            }
        }
        public string SalaryScope
        {
            get
            {
                return salaryScope;
            }
            set
            {
                salaryScope = value;
            }
        }
        public string LearnRequest
        {
            get
            {
                return learnRequest;
            }
            set
            {
                learnRequest = value;
            }
        }
        public string WorkTimeLimit
        {
            get
            {
                return workTimeLimit;
            }
            set
            {
                workTimeLimit = value;
            }
        }
        public string EnglishRequest
        {
            get
            {
                return englishRequest;
            }
            set
            {
                englishRequest = value;
            }
        }
        public string PostDescription
        {
            get
            {
                return postDescription;
            }
            set
            {
                postDescription = value;
            }
        }

        #endregion
        public Recruit()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
        }
    }
}
