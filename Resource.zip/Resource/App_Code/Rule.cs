﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace ResourceManage
{
    /// <summary>
    /// rule 的摘要说明
    /// </summary>
    public class Rule
    {
        #region 定义私有成员变量

        private int ruleID;//制度ID
        private string content;//内容

        #endregion

        #region  定义变量属性

        public int RuleID
        {
            get
            {
                return ruleID;
            }
            set
            {
                ruleID = value;
            }
        }
        public string Content
        {
            get
            {
                return content;
            }
            set
            {
                content = value;
            }
        }
        #endregion

        public Rule()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
        }
    }
}
