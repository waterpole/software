﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace ResourceManage
{
    /// <summary>
    /// CommentManage 的摘要说明
    /// </summary>
    public class CommentManage
    {
        public static SqlConnection myconn;
        static  CommentManage()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
            myconn = new SqlConnection();
            myconn.ConnectionString = ConfigurationManager.AppSettings["ConnectionString"];
            myconn.Open();
        }
        ~CommentManage()
        {
            myconn.Close();
        }

        #region 插入评价信息
        /// <summary>
        /// 插入评价信息
        /// </summary>
        /// <param name="cmt"></param>
        /// <returns></returns>
        public static bool InsertCommentInfo(Comment cmt)
        {
            bool ret = true;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            if (CheckIfExistInfo(cmt))
                cmd.CommandText = "update tb_comment set Comment=@comment where ID=@empID and employeeIdChecked=@empIdChecked";
            else
                cmd.CommandText = "insert into tb_comment values(@empID,@empIdChecked,@comment)";
            cmd.Parameters.Add("@empID", SqlDbType.Int).Value = cmt.EmployeeID;
            cmd.Parameters.Add("@empIdChecked", SqlDbType.Int).Value = cmt.EmployeeIdChecked;
            cmd.Parameters.Add("@comment", SqlDbType.Text).Value = cmt.Content;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
                ret = false;
            }
            return ret;
        }
        #endregion

        public static bool CheckIfExistInfo(Comment cmt)//是否存在信息
        {
            bool ret = true;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select count(*) from tb_comment where ID=@empID and employeeIdChecked=@empIdChecked";
            cmd.Parameters.Add("@empID", SqlDbType.Int).Value = cmt.EmployeeID;
            cmd.Parameters.Add("@empIdChecked", SqlDbType.Int).Value = cmt.EmployeeIdChecked;
            cmd.Parameters.Add("@comment", SqlDbType.Text).Value = cmt.Content;
            cmd.Connection = myconn;
            int n = 0;
            try
            {
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    n = sdr.GetInt32(0);
                }
                sdr.Close();
                if (n >= 1)
                    ret = true;
                else
                    ret = false;
            }
            catch (Exception e)
            {
                string msg = e.Message;
                ret = false;
            }
            return ret;
        }
    }
}
