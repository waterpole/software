﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using ResourceManage;

namespace ResourceManage
{
    /// <summary>
    /// DepartmentManage 的摘要说明
    /// </summary>
    public class DepartmentManage
    {
        public static SqlConnection myconn;
        static  DepartmentManage()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
            myconn = new SqlConnection();
            myconn.ConnectionString = ConfigurationManager.AppSettings["ConnectionString"];
            myconn.Open();
        }
        ~ DepartmentManage()
        {
            myconn.Close();
        }

        #region 查找所有部门信息
        /// <summary>
        /// 查找所有部门信息
        /// </summary>
        /// <returns>部门信息表</returns>
        public static DataTable GetAllDeptInfo()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from tb_department";
            cmd.Connection = myconn;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            ds.Clear();
            try
            {
                cmd.ExecuteNonQuery();
                sda.Fill(ds, "dept");
            }
            catch(Exception ex)
            {
                string msg = ex.Message;
            }
            return ds.Tables["dept"];
        }
        #endregion

        #region  根据部门名称查找相关部门信息
        /// <summary>
        /// 根据部门名称查找相关部门信息
        /// </summary>
        /// <param name="deptID">部门名称</param>
        /// <returns>部门信息</returns>
        public static DataTable GetDeptInfoByName(string deptName)
        {
            Department dept = new Department();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from tb_department where deptName=@deptname";
            cmd.Parameters.Add("@deptname", SqlDbType.Char, 50).Value = deptName;
            cmd.Connection = myconn;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dt.Clear();
 
            try
            {
                sda.Fill(dt);
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dt;
        }
        #endregion

        #region 查找所有部门名称
        /// <summary>
        /// 查找所有部门名称
        /// </summary>
        /// <returns>部门名称</returns>
        public static DataView GetAllDeptName()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select distinct deptName from tb_department";
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataView dv = new DataView();
            cmd.Connection = myconn;
            try
            {
                sda.Fill(ds, "deptname");
                dv = ds.Tables[0].DefaultView;
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
            }
            return dv;
        }
        #endregion

        #region 根据部门ID删除部门信息
        /// <summary>
        /// 根据部门ID删除部门信息
        /// </summary>
        /// <param name="id">部门ID</param>
        /// <returns>删除操作是否成功</returns>
        public static bool  DeleteDeptInfo(int  id)
        {
            bool ret = true;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from tb_department where deptID=@id";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
                ret = false;
            }
            return ret;
        }
        #endregion

        #region 更新部门信息
        /// <summary>
        /// 更新部门信息
        /// </summary>
        /// <param name="dept">部门信息</param>
        /// <returns>更新操作是否成功</returns>
        public static bool UpdateDeptInfo(Department dept)
        {
            bool ret = true;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update tb_department set deptName=@name,deptAddr=@address,deptTel=@tel,deptMemo=@memo where deptID=@id";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = dept.Dept_ID;
            cmd.Parameters.Add("@name", SqlDbType.Char, 50).Value = dept.Dept_Name;
            cmd.Parameters.Add("@address", SqlDbType.Char, 100).Value = dept.Dept_Addr;
            cmd.Parameters.Add("@tel", SqlDbType.Char, 20).Value = dept.Dept_Tel;
            cmd.Parameters.Add("@memo", SqlDbType.Text).Value = dept.Dept_Memo;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
                ret = false;
            }
            return ret;
        }
        #endregion

        #region 添加部门信息
        /// <summary>
        /// 添加部门信息
        /// </summary>
        /// <param name="dept">部门信息</param>
        /// <returns>添加操作是否成功</returns>
        public static bool  AddDeptInfo(Department dept)
        {
            bool ret = true;
            SqlCommand cmd=new SqlCommand ();
            cmd.CommandType=CommandType.Text;
            cmd.CommandText="insert into tb_department values(@name,@address,@tel,@memo)";
            cmd.Parameters.Add("@name",SqlDbType.Char,50).Value=dept.Dept_Name;
            cmd.Parameters.Add("@address",SqlDbType.Char,100).Value=dept.Dept_Addr;
            cmd.Parameters.Add("@tel",SqlDbType.Char,20).Value=dept.Dept_Tel;
            cmd.Parameters.Add("@memo",SqlDbType.Text).Value=dept.Dept_Memo;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
                ret = false;
            }
            return ret;
        }
        #endregion

     
        #region 根据部门名称查找部门号
        /// <summary>
        /// 根据部门名称查找部门号
        /// </summary>
        /// <param name="deptname">部门名称</param>
        /// <returns>返回部门号</returns>
        public static int GetDeptIdByName(string deptname)
        {
            int deptID=0;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select distinct deptID from tb_department where deptName=@deptname";
            cmd.Parameters.Add("@deptname", SqlDbType.Char, 50).Value = deptname;
            
            cmd.Connection = myconn;
            try
            {
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    deptID = sdr.GetInt32(0);
                }
                sdr.Close();       
            }
            catch (Exception e)
            {
                 string msg = e.Message;
            }
            return deptID;
        }
        #endregion
   

        #region 根据职工号查找部门名称
        /// <summary>
        /// 根据职工号查找部门名称
        /// </summary>
        /// <param name="deptid">部门号</param>
        /// <returns>部门名称</returns>
        public static string GetDeptNameById(int id)
        {
            string deptname="";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select distinct b.deptName from tb_employee a,tb_department b where a.deptID=b.deptID and ID=@id";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
            cmd.Connection = myconn;
            try
            {
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    deptname = sdr.GetString(0);
                }
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
            }
            return deptname;
        }
        #endregion

        #region 根据部门名称查找相关信息
        /// <summary>
        /// 根据部门名称查找相关信息
        /// </summary>
        /// 
        /// <returns></returns>
        public static Department GetADeptInfo(int  id)
        {
            Department dept=new Department ();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from tb_department where deptID in (select deptID from tb_employee where ID=@id)";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
            cmd.Connection = myconn;
            try
            {
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    dept.Dept_ID = sdr.GetInt32(0);
                    dept.Dept_Name = sdr.GetString(1);
                    dept.Dept_Addr = sdr.GetString(2);
                    dept.Dept_Tel = sdr.GetString(3);
                    dept.Dept_Memo = sdr.GetString(4);
                }
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dept;
        }
        #endregion
    }
}
