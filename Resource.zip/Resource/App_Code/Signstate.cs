﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace ResourceManage
{
    /// <summary>
    /// signstate 的摘要说明
    /// </summary>
    public class Signstate
    {
        #region 定义私有成员变量

        private int signstateID;//签到表ID
        private string describestate;//描述
        private DateTime time;//上下班时间规定

        #endregion

        #region  定义属性

        public int SignstateID
        {
            get
            {
                return signstateID;
            }
            set
            {
                signstateID = value;
            }
        }
        public string Describestate
        {
            get
            {
                return describestate;
            }
            set
            {
                describestate = value;
            }
        }
        public DateTime Time
        {
            get
            {
                return time;
            }
            set
            {
                time = value;
            }
        }

        #endregion
        public Signstate()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
        }
    }
}
