﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace ResourceManage
{
    /// <summary>
    /// CheckResult 的摘要说明
    /// </summary>
    public class CheckResult
    {
        #region
        private int employeeID;//考核员工编号
        private int employeeIdChecked;//被考核员工编号
        private int itemID;//考核项目编号
        private int grade;//考核项目成绩
        #endregion

        #region
        public int EmployeeID
        {
            get
            {
                return employeeID;
            }
            set
            {
                employeeID = value;
            }
        }

        public int EmployeeIdChecked
        {
            get
            {
                return employeeIdChecked;
            }
            set
            {
                employeeIdChecked = value;
            }
        }

        public int ItemID
        {
            get
            {
                return itemID;
            }
            set
            {
                itemID = value;
            }
        }

        public int Grade
        {
            get
            {
                return grade;
            }
            set
            {
                grade = value;
            }
        }
        #endregion
        public CheckResult()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
        }
    }
}
