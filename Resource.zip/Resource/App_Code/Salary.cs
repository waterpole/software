﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace ResourceManage
{
    /// <summary>
    /// Salary 的摘要说明
    /// </summary>
    public class Salary
    {
        #region 定义私有成员变量

        private int salaryID;//工资表ID
        private int  e_ID;//员工ID
        private string year;//年份
        private string month;//月份
        private int baseSalary;//基本工资
        private int resultWage;//绩效工资
        private int wholeAttendancePrice;//全勤奖
        private int overTimePay;//加班费
        private int addUp;//合计工资

        #endregion

        #region  定义变量属性

        public int SalaryID
        {
            get
            {
                return salaryID;
            }
            set
            {
                salaryID = value;
            }
        }
        public int  E_ID
        {
            get
            {
                return e_ID;
            }
            set
            {
                e_ID = value;
            }
        }
        public string Year
        {
            get
            {
                return year;
            }
            set
            {
                year = value;
            }
        }
        public string Month
        {
            get
            {
                return month;
            }
            set
            {
                month = value;
            }
        }
        public int BaseSalary
        {
            get
            {
                return baseSalary;
            }
            set
            {
                baseSalary = value;
            }
        }
        public int ResultWage
        {
            get
            {
                return resultWage;
            }
            set
            {
                resultWage = value;
            }
        }
        public int WholeAttendancePrice
        {
            get
            {
                return wholeAttendancePrice;
            }
            set
            {
                wholeAttendancePrice = value;
            }
        }
        public int OverTimePay
        {
            get
            {
                return overTimePay;
            }
            set
            {
                overTimePay = value;
            }
        }
        public int AddUp
        {
            get
            {
                return addUp;
            }
            set
            {
                addUp=value;
            }
        }
        #endregion
        public Salary()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
        }
    }
}
