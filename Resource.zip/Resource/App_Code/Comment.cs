﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace ResourceManage
{
    /// <summary>
    /// Comment 的摘要说明
    /// </summary>
    public class Comment
    {
        #region

        private int employeeID;//考核员工编号
        private int employeeIdChecked;//被考核员工编号
        private string content;//建议内容

        #endregion

        #region
        public int EmployeeID
        {
            get
            {
                return employeeID;
            }
            set
            {
                employeeID = value;
            }
        }

        public int EmployeeIdChecked
        {
            get
            {
                return employeeIdChecked;
            }
            set
            {
                employeeIdChecked = value;
            }
        }

        public string Content
        {
            get
            {
                return content;
            }
            set
            {
                content = value;
            }
        }
        #endregion
        public Comment()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
        }
    }
}
