﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace ResourceManage
{
    /// <summary>
    /// department 的摘要说明
    /// </summary>
    public class Department
    {
        #region 定义私有成员变量

        private int  dept_ID;
        private string dept_Name;
        private string dept_Addr;
        private string dept_Tel;
        private string dept_Memo;

        #endregion

        #region 定义属性
        public int   Dept_ID  //部门ID
        {
            get
            {
                return dept_ID;
            }
            set
            {
                dept_ID = value;

            }
        }
        public string Dept_Name  //部门名称
        {
            get
            {
                return dept_Name;
            }
            set
            {
                dept_Name = value;
            }
        }
        public string Dept_Addr  //部门地址
        {
            get
            {
                return dept_Addr;
            }
            set
            {
                dept_Addr = value;
            }
        }
        public string Dept_Tel  //部门电话
        {
            get
            {
                return dept_Tel;
            }
            set
            {
                dept_Tel = value;
            }
        }
        public string Dept_Memo  //部门描述
        {
            get
            {
                return dept_Memo;
            }
            set
            {
                dept_Memo = value;
            }
        }

        #endregion
        public Department()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
        }
    }
}
