﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace ResourceManage
{
    /// <summary>
    /// ruleManage 的摘要说明
    /// </summary>
    public class ruleManage
    {
        public static SqlConnection myconn;
        static ruleManage()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
            myconn = new SqlConnection();
            myconn.ConnectionString = ConfigurationManager.AppSettings["ConnectionString"];
            myconn.Open();
        }
        ~ruleManage()
        {
            myconn.Close();
        }

        #region 查找公司制度信息
        /// <summary>
        /// 查找公司制度信息
        /// </summary>
        /// <returns>制度信息视图</returns>
        public static DataView GetRuleInfo()
        {
            Rule rule = new Rule();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from tb_rule ";
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataView dv = new DataView();
            ds.Clear();
            cmd.Connection = myconn;

            try
            {
                sda.Fill(ds, "rule");
                dv = ds.Tables[0].DefaultView;
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dv;
        }
        #endregion

        #region 更新公司制度
        /// <summary>
        /// 更新公司制度
        /// </summary>
        /// <param name="content">修改后的制度内容</param>
        /// <returns>返回更新是否成功的标志</returns>
        public static bool UpdateRuleInfo(string content)
        {
            bool ret = true;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update tb_rule set Content=@content where RuleID=0 ";
            cmd.Parameters.Add("@content", SqlDbType.Text).Value = content;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
                ret = false;
            }
            return ret;
        }
        #endregion

    }
}
