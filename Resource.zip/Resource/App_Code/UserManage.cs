﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace ResourceManage
{
    /// <summary>
    /// UserManage 的摘要说明
    /// </summary>
    public class UserManage
    {
        public static SqlConnection myconn;
        static UserManage()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
            myconn = new SqlConnection();
            myconn.ConnectionString = ConfigurationManager.AppSettings["ConnectionString"];
            myconn.Open();
        }
        ~UserManage()
        {
            myconn.Close();
        }

        #region 根据给定的条件查询表记录数
        /// <summary>
        /// 根据给定的条件查询表记录数
        /// </summary>
        /// <param name="name">用户名</param>
        /// <param name="pwd">用户密码</param>
        /// <returns>返回查询结果的第一行第一列</returns>
        public static int GetInfoCount(string name, string pwd)
        {
            int i=0;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select count(*) from tb_user where UserName=@name and UserPwd=@pwd ";
            cmd.Parameters.Add("@name", SqlDbType.VarChar, 20).Value = name;
            cmd.Parameters.Add("@pwd", SqlDbType.VarChar, 20).Value = pwd;
            if(myconn.State==ConnectionState.Closed)
                myconn.Open();
            cmd.Connection = myconn;
            try
            {
                i =Convert.ToInt32( cmd.ExecuteScalar());//执行查询,并返回结果中的第一行第一列的结果,其它行乎略
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return i;
        }
        #endregion

        #region 添加登录用户信息
        /// <summary>
        /// 添加登录用户信息
        /// </summary>
        /// <param name="user">用户信息类</param>
        /// <returns>返回操作是否成功的标志</returns>
        public static bool AddUserInfo(User user)
        {
            bool ret = true;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into tb_user( UserName,UserPwd,LoginTime,UserLevel) values(@name,@pwd,@date,@level)";
            cmd.Parameters.Add("@name", SqlDbType.VarChar, 20).Value = user.UserName;
            cmd.Parameters.Add("@pwd", SqlDbType.VarChar, 20).Value = user.UserPwd;
            cmd.Parameters.Add("@date", SqlDbType.DateTime).Value = user.LoginTime;
            cmd.Parameters.Add("@level", SqlDbType.Int).Value = user.UserLevel;
            if (myconn.State == ConnectionState.Closed)
                myconn.Open();
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
                ret = false;
            }
            return ret;
        }
        #endregion

        #region 更新用户密码
        /// <summary>
        /// 更新用户密码
        /// </summary>
        /// <param name="name">用户名</param>
        /// <param name="pwd">用户密码 </param>
        /// <returns>返回更新是否成功的标志</returns>
        public static bool UpdateUserPwd(string name, string pwd)
        {
            bool ret = true;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update  tb_user set UserPwd=@pwd where UserName=@name";
            cmd.Parameters.Add("@name", SqlDbType.VarChar, 20).Value = name;
            cmd.Parameters.Add("@pwd", SqlDbType.VarChar, 20).Value = pwd;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
                ret = false;
            }
            return ret;
        }
        public static bool UpdateLoginTime(string name)
        {
            bool ret = true;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update  tb_user set LoginTime=getdate() where UserName=@name";
            cmd.Parameters.Add("@name", SqlDbType.VarChar, 20).Value = name;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
                ret = false;
            }
            return ret;
        }
        #endregion

        #region 查找所有用户信息
        /// <summary>
        /// 查找所有用户信息
        /// </summary>
        /// <returns>返回用户信息表</returns>
        public static DataTable GetAllUserInfo()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from tb_user order by UserID";
            cmd.Connection = myconn;
            SqlDataAdapter sda=new SqlDataAdapter (cmd);
            DataTable dt=new DataTable ();
            dt.Clear();
            try
            {
                cmd.ExecuteNonQuery();
                sda.Fill(dt);
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dt;
        }
        #endregion

        #region 查找所有用户信息
        /// <summary>
        /// 查找所有用户信息
        /// </summary>
        /// <returns>返回用户信息表</returns>
        public static DataTable GetUserInfo(int level)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            if (level == 0)
                cmd.CommandText = "select * from tb_user order by UserID";
            else if (level == 1)
                cmd.CommandText = "select * from tb_user where UserLevel=2 order by UserID";
            else
                return null;
          if (myconn.State == ConnectionState.Closed)
              myconn.Open();
            cmd.Connection = myconn;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dt.Clear();
            try
            {
                cmd.ExecuteNonQuery();
                sda.Fill(dt);
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dt;
        }
        #endregion


        #region 查找所有普通用户信息
        /// <summary>
        /// 查找所有普通用户信息
        /// </summary>
        /// <returns>返回普通用户信息表</returns>
        public static DataTable GetAllUsualUserInfo()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from tb_user where UserLevel=2 order by UserID";
            if (myconn.State == ConnectionState.Closed)
                myconn.Open();
            cmd.Connection = myconn;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dt.Clear();
            try
            {
                cmd.ExecuteNonQuery();
                sda.Fill(dt);
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dt;
        }
        #endregion


        #region 根据用户ID删除其相关信息
        /// <summary>
        /// 根据用户ID删除其相关信息
        /// </summary>
        /// <param name="id">用户ID</param>
        /// <returns>返回删除操作是否成功的标志</returns>
        public static bool DeleteUserInfoById(int id)
        {
            bool ret = true;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from tb_user where  UserID=@id";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
                ret = false;
            }
            return ret;
        }
        #endregion

        /*
        #region
        /// <summary>
        /// 更新登录状态
        /// </summary>
        /// <param name="username">用户名</param>
        ///
        public static void UpdateState(string username,Boolean state)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update  tb_user set IfSign=@state where UserName=@name";
            cmd.Parameters.Add("@name", SqlDbType.VarChar, 20).Value = username;
            cmd.Parameters.Add("@state", SqlDbType.Bit).Value = state;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
        }
        #endregion

         * */
        #region 查找用户是否已经存在
        /// <summary>
        /// 查找用户是否已经存在
        /// </summary>
        /// <param name="username">用户名</param>
        /// <param name="userlevel">用户级别</param>
        /// <returns>返回是否存在的标志</returns>
        public static bool IfExistUser(string username, int userlevel)
        {
            bool ret = false;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select count(*) from tb_user where UserName=@name and UserLevel=@level";
            cmd.Parameters.Add("@name", SqlDbType.VarChar, 20).Value = username;
            cmd.Parameters.Add("@level", SqlDbType.Int).Value = userlevel;
            cmd.Connection = myconn;
            try
            {
                int i = (int)cmd.ExecuteScalar();
                if (i > 0)
                {
                    ret = true;
                }
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return ret;
        }
        #endregion

        #region 查找用户输入的密码是否正确
        /// <summary>
        /// 查找用户输入的密码是否正确
        /// </summary>
        /// <param name="username">用户名</param>
        /// <param name="userId">用户ID</param>
        ///<param name="userpwd">用户密码</param>
        /// <returns>返回是否存在的标志</returns>
        public static bool IfExistPwd(string username,string userpwd)
        {
            bool ret = false;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select count(*) from tb_user where UserName=@name  and UserPwd=@pwd";
            cmd.Parameters.Add("@name", SqlDbType.VarChar, 20).Value = username;
            cmd.Parameters.Add("@pwd", SqlDbType.VarChar, 20).Value = userpwd;
            cmd.Connection = myconn;
            try
            {
                int i = (int)cmd.ExecuteScalar();
                if (i > 0)
                {
                    ret = true;
                }
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return ret;
        }
        #endregion

        #region 根据用户名删除其相关信息
        /// <summary>
        /// 根据用户名删除其相关信息
        /// </summary>
        /// <param name="name">用户名</param>
        public static void DeleteUserInfoByName(string name)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from tb_user where  UserName=@name";
            cmd.Parameters.Add("@name", SqlDbType.VarChar,20).Value = name;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
        }
        #endregion
    }
}
