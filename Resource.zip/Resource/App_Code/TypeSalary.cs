﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace ResourceManage
{
    /// <summary>
    /// TypeSalary 的摘要说明
    /// </summary>
    public class TypeSalary
    {
        private string type;
        private int typesalary;
        private string units;

        public string Type
        {
            get
            {
                return type;
            }
            set
            {
                type = value;
            }
        }

        public int typeSalary
        {
            get
            {
                return typesalary;
            }
            set
            {
                typesalary = value;
            }
        }

        public string Units
        {
            get
            {
                return units;
            }
            set
            {
                units = value;
            }
        }

        public TypeSalary()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
        }
    }
}
