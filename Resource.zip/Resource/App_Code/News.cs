﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace ResourceManage
{
    /// <summary>
    /// News 的摘要说明
    /// </summary>
    public class News
    {
        #region 定义私有成员变量

        private int newsID;//新闻ID
        private string newsTitle;//新闻标题
        private string newsContent;//新闻内容
        private DateTime newsCreatTime;//新闻创建时间
        private DateTime newsPublishDate;//新闻发布时间
        private string newsCreator;//新闻创建人
        private bool ifPublish;//是否发布
        private bool ifAutoPopUp;//是否自动弹出
        private int viewCounter;//查看新闻人数

        #endregion

        #region 定义变量属性

        public int NewsID
        {
            get
            {
                return newsID;
            }
            set
            {
                newsID = value;
            }
        }
        public string NewsTitle
        {
            get
            {
                return newsTitle;
            }
            set
            {
                newsTitle = value;
            }
        }
        public string NewsContent
        {
            get
            {
                return newsContent;
            }
            set
            {
                newsContent = value;
            }
        }
        public DateTime NewsCreateTime
        {
            get
            {
                return newsCreatTime;
            }
            set
            {
                newsCreatTime = value;
            }
        }
        public DateTime NewsPublishDate
        {
            get
            {
                return newsPublishDate;
            }
            set
            {
                newsPublishDate = value;
            }
        }
        public string NewsCreator
        {
            get
            {
                return newsCreator;
            }
            set
            {
                newsCreator = value;
            }
        }
        public bool IfPublish
        {
            get
            {
                return ifPublish;
            }
            set
            {
                ifPublish = value;
            }
        }
        public bool IfAutoPopUp
        {
            get
            {
                return ifAutoPopUp;
            }
            set
            {
                ifAutoPopUp = value;
            }
        }
        public int ViewCounter
        {
            get
            {
                return viewCounter;
            }
            set
            {
                viewCounter = value;
            }
        }
        #endregion
        public News()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
        }
    }
}
