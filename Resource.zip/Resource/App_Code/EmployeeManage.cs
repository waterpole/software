﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace ResourceManage
{
    /// <summary>
    /// EmployeeManage 的摘要说明
    /// </summary>
    public class EmployeeManage
    {
        public  static SqlConnection myconn;
        static  EmployeeManage()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
            myconn = new SqlConnection();
            myconn.ConnectionString = ConfigurationManager.AppSettings["ConnectionString"];
            myconn.Open();
        }
        ~EmployeeManage()
        {
            myconn.Close();
        }

        #region  查找所有员工信息
        /// <summary>
        /// 查找所有员工信息
        /// </summary>
        /// <returns>员工信息表</returns>
        public static DataTable GetAllEmployeeInfo()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select a.*,b.deptName from tb_employee a,tb_department b where a.deptID=b.deptID order by a.deptID,a.ID";
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dt.Clear();
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
                sda.Fill(dt);
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dt;
        }
        #endregion

        #region 查找所有员工姓名
        /// <summary>
        /// 查找所有员工姓名
        /// </summary>
        /// <returns>员工姓名视图</returns>
        public static DataView GetAllEmployeeName()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select distinct Name from tb_employee ";
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataView dv = new DataView();
            cmd.Connection = myconn;
            try
            {
                sda.Fill(ds, "name");
                dv = ds.Tables[0].DefaultView;
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dv;
        }
        #endregion


        #region 查找给定部门名称的所有员工信息
        /// <summary>
        /// 查找给定部门名称的所有员工信息
        /// </summary>
        /// <param name="deptname">部门名称</param>
        /// <returns>部门信息</returns>
        public static DataView GetEmployeeInfoByDeptname(string deptname)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select a.* from tb_employee a,tb_department b where a.deptID=b.deptID and b.deptName=@deptname";
            cmd.Parameters.Add("@deptname", SqlDbType.VarChar,50).Value = deptname;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataView dv = new DataView();
            cmd.Connection = myconn;
            try
            {
                sda.Fill(ds, "employee");
                dv = ds.Tables[0].DefaultView;
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dv;
        }
        #endregion

        #region 根据部门名称查找所有员工信息
        /// <summary>
        /// 根据部门名称查找所有员工信息
        /// </summary>
        /// <param name="deptname">部门名称</param>
        /// <returns>员工信息表</returns>
        public static DataTable GetAllEmpInfoByDeptName(string deptname)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select a.*,b.deptName from tb_employee a,tb_department b where a.deptID=b.deptID and b.deptName=@deptname";
            cmd.Parameters.Add("@deptname", SqlDbType.VarChar, 50).Value = deptname;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dt.Clear();
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
                sda.Fill(dt);
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dt;
        }
        #endregion

        #region 根据员工姓名查找信息
        /// <summary>
        /// 根据员工姓名查找信息
        /// </summary>
        /// <param name="name">员工姓名</param>
        /// <returns>员工信息</returns>
        public static DataTable GetAllEmpInfoByName(string name)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from tb_employee where Name=@name";
            cmd.Parameters.Add("@name", SqlDbType.Char, 10).Value = name;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dt.Clear();
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
                sda.Fill(dt);
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dt;
        }
        #endregion

        #region  根据职工ID删除其相关信息
        /// <summary>
        /// 根据职工ID删除其相关信息
        /// </summary>
        /// <param name="id">职工ID</param>
        /// <returns>删除操作是否成功</returns>
        public static bool DeleteEmpInfoByID(int id)
        {
            bool ret = true;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from tb_employee where ID=@id";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
                ret = false;
            }
            return ret;
        }
        #endregion

        #region 添加员工信息
        /// <summary>
        /// 添加员工信息
        /// </summary>
        /// <param name="emp">员工信息</param>
        /// <returns>返回添加操作是否成功的标志</returns>
        public static bool AddEmpInfo(Employee emp)
        {
            bool ret = true;
            SqlCommand cmd = new SqlCommand();
            
            string sql="insert into tb_employee (Name,Sex,Birthday,MaritalStatus,Learn,Major,PoliticsFace,NativePlace,Race,Address,Post,Job,deptID,Statues,";
            sql+="Superior,MobilePhone,Phone,Email,QQ,MSN,Interest,BeginWorkTime,IntoCompanyTime,RiseSalaryTime,IntoDeptTime,TitleTime,ExperienceSkill,PhotoPath,Remarks) ";
            sql+="values(@name,@sex,@birth,@marital,@learn,@major,@politic,@native,@race,@address,@post,@job,@deptid,@status,@superior,@mobile,@phone,@email,@qq,@msn,";
            sql+="@interest,@beginworktime,@intocompanytime,@risesalarytime,@intodepttime,@titletime,@experience,@path,@remark)";
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = sql;
            cmd.Parameters.Add("@name", SqlDbType.Char, 10).Value = emp.E_Name;
            cmd.Parameters.Add("@sex", SqlDbType.Char,2).Value = emp.E_Sex;
            cmd.Parameters.Add("@birth", SqlDbType.DateTime).Value = emp.E_Birthday;
            cmd.Parameters.Add("@marital", SqlDbType.Bit).Value = emp.E_MaritalStatus;
            cmd.Parameters.Add("@learn", SqlDbType.Char, 20).Value = emp.E_Learn;
            cmd.Parameters.Add("@major", SqlDbType.Char, 20).Value = emp.E_Major;
            cmd.Parameters.Add("@politic", SqlDbType.Char, 20).Value = emp.E_PoliticsFace;
            cmd.Parameters.Add("@native", SqlDbType.Char, 20).Value = emp.E_NativePlace;
            cmd.Parameters.Add("@race", SqlDbType.Char, 10).Value = emp.E_Race;
            cmd.Parameters.Add("@address", SqlDbType.Char, 100).Value = emp.E_Address;
            cmd.Parameters.Add("@post", SqlDbType.Char, 20).Value = emp.E_Post;
            cmd.Parameters.Add("@job", SqlDbType.Char, 50).Value = emp.E_Job;
            cmd.Parameters.Add("@deptid", SqlDbType.Int).Value = emp.E_deptID;
            cmd.Parameters.Add("@status", SqlDbType.Bit).Value = emp.E_Status;
            cmd.Parameters.Add("@superior", SqlDbType.Char, 10).Value = emp.E_Superior;
            cmd.Parameters.Add("@mobile", SqlDbType.Char, 20).Value = emp.E_MobilePhone;
            cmd.Parameters.Add("@phone", SqlDbType.Char, 20).Value = emp.E_Phone;
            cmd.Parameters.Add("@email", SqlDbType.Char, 50).Value = emp.E_Email;
            cmd.Parameters.Add("@qq", SqlDbType.Char, 20).Value = emp.E_QQ;
            cmd.Parameters.Add("@msn", SqlDbType.Char, 50).Value = emp.E_MSN;
            cmd.Parameters.Add("@interest", SqlDbType.Char,100).Value = emp.E_Interest;
            cmd.Parameters.Add("@beginworktime", SqlDbType.DateTime).Value = emp.E_BeginWorkTime;
            cmd.Parameters.Add("@intocompanytime", SqlDbType.DateTime).Value = emp.E_IntoCompanyTime;
            cmd.Parameters.Add("@risesalarytime", SqlDbType.DateTime).Value = emp.E_RiseSalaryTime;
            cmd.Parameters.Add("@intodepttime", SqlDbType.DateTime).Value = emp.E_IntoDeptTime;
            cmd.Parameters.Add("@titletime", SqlDbType.DateTime).Value = emp.E_TitleTime;
            cmd.Parameters.Add("@experience", SqlDbType.Text).Value = emp.E_ExperienceSkill;
            cmd.Parameters.Add("@path", SqlDbType.Char,100).Value = emp.E_PhotoPath;
            cmd.Parameters.Add("@remark", SqlDbType.Text).Value = emp.E_Remarks;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
                ret = false;
            }
            return ret;
               
        }
        #endregion

        #region 更新员工信息
        /// <summary>
        /// 更新员工信息
        /// </summary>
        /// <param name="emp">员工信息</param>
        /// <returns>返回更新操作是否成功的标志</returns>
        public static bool UpdateEmpInfo(Employee emp)
        {
            bool ret = true;
            SqlCommand cmd = new SqlCommand();

            string sql = "update tb_employee set Name=@name,Sex=@sex,Birthday=@birth,MaritalStatus=@marital,Learn=@learn,Major=@major,PoliticsFace=@politic,NativePlace=@native,Race=@race,Address=@address,Post=@post,Job=@job,deptID=@deptid,Statues=@status,";
            sql += "Superior=@superior,MobilePhone=@mobile,Phone=@phone,Email=@email,QQ=@qq,MSN=@msn,Interest=@interest,BeginWorkTime=@beginworktime,IntoCompanyTime=@intocompanytime,RiseSalaryTime=@risesalarytime,IntoDeptTime=@intodepttime,TitleTime=@titletime,ExperienceSkill=@experience,PhotoPath=@path,Remarks=@remark where ID=@id";
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = sql;
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = emp.E_ID;
            cmd.Parameters.Add("@name", SqlDbType.VarChar, 10).Value = emp.E_Name;
            cmd.Parameters.Add("@sex", SqlDbType.Char, 2).Value = emp.E_Sex;
            cmd.Parameters.Add("@birth", SqlDbType.DateTime).Value = emp.E_Birthday;
            cmd.Parameters.Add("@marital", SqlDbType.Bit).Value = emp.E_MaritalStatus;
            cmd.Parameters.Add("@learn", SqlDbType.VarChar, 20).Value = emp.E_Learn;
            cmd.Parameters.Add("@major", SqlDbType.VarChar, 20).Value = emp.E_Major;
            cmd.Parameters.Add("@politic", SqlDbType.VarChar, 20).Value = emp.E_PoliticsFace;
            cmd.Parameters.Add("@native", SqlDbType.VarChar, 20).Value = emp.E_NativePlace;
            cmd.Parameters.Add("@race", SqlDbType.VarChar, 10).Value = emp.E_Race;
            cmd.Parameters.Add("@address", SqlDbType.VarChar, 100).Value = emp.E_Address;
            cmd.Parameters.Add("@post", SqlDbType.VarChar, 20).Value = emp.E_Post;
            cmd.Parameters.Add("@job", SqlDbType.VarChar, 50).Value = emp.E_Job;
            cmd.Parameters.Add("@deptid", SqlDbType.Int).Value = emp.E_deptID;
            cmd.Parameters.Add("@status", SqlDbType.Bit).Value = emp.E_Status;
            cmd.Parameters.Add("@superior", SqlDbType.VarChar, 10).Value = emp.E_Superior;
            cmd.Parameters.Add("@mobile", SqlDbType.VarChar, 20).Value = emp.E_MobilePhone;
            cmd.Parameters.Add("@phone", SqlDbType.VarChar, 20).Value = emp.E_Phone;
            cmd.Parameters.Add("@email", SqlDbType.VarChar, 50).Value = emp.E_Email;
            cmd.Parameters.Add("@qq", SqlDbType.VarChar, 20).Value = emp.E_QQ;
            cmd.Parameters.Add("@msn", SqlDbType.VarChar, 50).Value = emp.E_MSN;
            cmd.Parameters.Add("@interest", SqlDbType.VarChar ,100).Value = emp.E_Interest;
            cmd.Parameters.Add("@beginworktime", SqlDbType.DateTime).Value = emp.E_BeginWorkTime;
            cmd.Parameters.Add("@intocompanytime", SqlDbType.DateTime).Value = emp.E_IntoCompanyTime;
            cmd.Parameters.Add("@risesalarytime", SqlDbType.DateTime).Value = emp.E_RiseSalaryTime;
            cmd.Parameters.Add("@intodepttime", SqlDbType.DateTime).Value = emp.E_IntoDeptTime;
            cmd.Parameters.Add("@titletime", SqlDbType.DateTime).Value = emp.E_TitleTime;
            cmd.Parameters.Add("@experience", SqlDbType.Text).Value = emp.E_ExperienceSkill;
            cmd.Parameters.Add("@path", SqlDbType.VarChar, 100).Value = emp.E_PhotoPath;
            cmd.Parameters.Add("@remark", SqlDbType.Text).Value = emp.E_Remarks;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
                ret = false;
            }
            return ret;

        }
        #endregion

        #region 根据员工号查询员工信息
        /// <summary>
        /// 根据员工号查询员工信息
        /// </summary>
        /// <param name="id">员工号</param>
        /// <returns>员工信息表</returns>
        public static DataTable GetEmpInfoById(int id)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from tb_employee where ID=@id";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dt.Clear();
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
                sda.Fill(dt);
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dt;
        }
        #endregion

        #region 根据员工号查询员工信息
        /// <summary>
        /// 根据员工号查询员工信息
        /// </summary>
        /// <param name="id">员工号</param>
        /// <returns>员工信息类</returns>
        public static Employee GetEmpInfoByIdView(int id)
        {
            Employee emp = new Employee();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from tb_employee  where ID=@id";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
            cmd.Connection = myconn;
            try
            {
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    emp.E_ID = id;
                    emp.E_Name = sdr.GetString(1);
                    emp.E_Sex = sdr.GetString(2);
                    emp.E_Birthday = sdr.GetDateTime(3);
                    emp.E_MaritalStatus = sdr.GetBoolean(4);
                    emp.E_Learn = sdr.GetString(5);
                    emp.E_Major = sdr.GetString(6);
                    emp.E_PoliticsFace = sdr.GetString(7);
                    emp.E_NativePlace = sdr.GetString(8);
                    emp.E_Race = sdr.GetString(9);
                    emp.E_Address = sdr.GetString(10);
                    emp.E_Post = sdr.GetString(11);
                    emp.E_Job = sdr.GetString(12);
                    emp.E_deptID = sdr.GetInt32(13);
                    emp.E_Status = sdr.GetBoolean(14);
                    emp.E_Superior = sdr.GetString(15);
                    emp.E_MobilePhone = sdr.GetString(16);
                    emp.E_Phone = sdr.GetString(17);
                    emp.E_Email = sdr.GetString(18);
                    emp.E_QQ = sdr.GetString(19);
                    emp.E_MSN = sdr.GetString(20).ToString();
                    emp.E_Interest = sdr.GetString(21);
                    emp.E_BeginWorkTime = sdr.GetDateTime(22);
                    emp.E_IntoCompanyTime = sdr.GetDateTime(23);
                    emp.E_RiseSalaryTime = sdr.GetDateTime(24);
                    emp.E_IntoDeptTime = sdr.GetDateTime(25);
                    emp.E_TitleTime = sdr.GetDateTime(26);
                    emp.E_ExperienceSkill = sdr.GetString(27);
                    emp.E_PhotoPath = sdr.GetString(28);
                    emp.E_Remarks = sdr.GetString(29);
                }
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return emp;
        }
        #endregion



        #region 根据职工ID号查找其姓名
        /// <summary>
        /// 根据职工ID号查找其姓名
        /// </summary>
        /// <param name="id">职工ID号</param>
        /// <returns>返回职工姓名</returns>
        public static string GetNameById(int id)
        {
            string name="";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select  Name from tb_employee where ID=@id";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
            cmd.Connection = myconn;
            try
            {
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    name = sdr.GetString(0);
                }
                sdr.Close();
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return name;
        }
        #endregion


        #region 根据职工ID号判断是否存在这样的职工
        /// <summary>
        /// 根据职工ID号判断是否存在这样的职工
        /// </summary>
        /// <param name="id">职工ID</param>
        /// <returns>是否成功</returns>
        public static bool IfExistId(int  id)
        {
            bool exists = true;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select  count(*) from tb_employee where ID=@id";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
            cmd.Connection = myconn;
            try
            {
                string i =Convert.ToString( cmd.ExecuteScalar());
                if (i=="")
                {
                    exists = false;
                }
            }
            catch (Exception e)
            {
                string msg = e.Message;
                exists = false;
            }
            return exists;
        }
        #endregion

        #region 根据职工号查找职工姓名,职位与所在部门
        /// <summary>
        /// 根据职工号查找职工姓名,职位与所在部门
        /// </summary>
        /// <param name="id">职工号</param>
        /// <returns>返回信息视图</returns>
        public static DataView GetSomeInfoById(int  id)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select  Name,Job,deptName from tb_employee a,tb_department b where a.deptID=b.deptID and a.ID=@id";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
            cmd.Connection = myconn;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataView dv = new DataView();
            
            try
            {
                cmd.ExecuteNonQuery();
                sda.Fill(ds,"emplist");
                dv = ds.Tables[0].DefaultView;
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dv;
        }
        #endregion

        #region 查找所有跟某职工在同一部门的所有职工信息
        /// <summary>
        /// 查找所有跟某职工在同一部门的所有职工信息
        /// </summary>
        /// <param name="id">职工ID</param>
        /// <returns>职工信息表</returns>
        public static DataTable FindAllInSameDept(int  id)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            //cmd.CommandText = "select a.ID,a.Name,b.deptName,a.Job,sum(Grade) as Total from tb_employee a,tb_department b ,tb_checkResult c where a.deptID=b.deptID and a.deptID=(select deptID from tb_employee d where d.ID=@id) and a.ID<>@id and c.ID=@id and a.ID=c.employeeIdChecked group by a.ID,Name,deptName,Job";
            cmd.CommandText = "select ID,Name,deptName,Job from tb_employee a,tb_department b where a.deptID=b.deptID and a.deptID=(select deptID from tb_employee c where c.ID=@id) and a.ID<>@id";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dt.Clear();
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
                sda.Fill(dt);
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dt;
        }
        #endregion


        #region 查找所有岗位名称
        /// <summary>
        /// 查找所有岗位名称
        /// </summary>
        /// <returns>返回所有岗位视图</returns>
        public static DataView GetAllJob()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select distinct Job from tb_employee";
            cmd.Connection = myconn;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataView dv = new DataView();
            try
            {
                sda.Fill(ds, "job");
                dv = ds.Tables[0].DefaultView;
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dv;
        }
        #endregion

        #region　根据部门名称查找所有员工
        /// <summary>
        /// 根据部门名称查找所有员工
        /// </summary>
        /// <param name="deptName"></param>
        /// <returns></returns>
        public static DataView GetEmpNameByDeptName(string deptName)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select Name from tb_employee a,tb_department b where a.deptID=b.deptID and b.deptName=@deptname";
            cmd.Parameters.Add("@deptname", SqlDbType.VarChar, 50).Value =deptName;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataView dv = new DataView();
            cmd.Connection = myconn;
            try
            {
                sda.Fill(ds, "empname");
                dv = ds.Tables[0].DefaultView;
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dv;
        }
        #endregion


        #region　根据部门名称查找所有在该部门的员工编号
        /// <summary>
        /// 根据部门名称查找所有在该部门的员工编号
        /// </summary>
        /// <param name="dept">部门名称</param>
        /// <returns></returns>
        public static DataView GetAllIdByDeptName(string deptname)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select distinct ID from tb_employee a,tb_department b where a.deptID=b.deptID and b.deptName=@deptname";
            cmd.Parameters.Add("@deptname", SqlDbType.VarChar,50).Value = deptname;
            cmd.Connection = myconn;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataView dv = new DataView();
            try
            {
                sda.Fill(ds, "id");
                dv = ds.Tables[0].DefaultView;
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dv;
        }
        #endregion
    }
}
