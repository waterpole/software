﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace ResourceManage
{
    /// <summary>
    /// JobSalary 的摘要说明
    /// </summary>
    public class JobSalary
    {
        private string job;//岗位
        private int salary;//岗位基本工资

        public string Job
        {
            get
            {
                return job;
            }
            set
            {
                job = value;
            }
        }

        public int Salary
        {
            get
            {
                return salary;
            }
            set
            {
                salary = value;
            }
        }
        public JobSalary()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
        }
    }
}
