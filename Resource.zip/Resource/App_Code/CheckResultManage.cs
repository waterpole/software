﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace ResourceManage
{
    /// <summary>
    /// CheckResultManage 的摘要说明
    /// </summary>
    public class CheckResultManage
    {
        public static SqlConnection myconn;
        static CheckResultManage()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
            myconn = new SqlConnection();
            myconn.ConnectionString = ConfigurationManager.AppSettings["ConnectionString"];
            myconn.Open();
        }
        ~CheckResultManage()
        {
            myconn.Close();
        }

        #region 插入员工考核结果信息
        /// <summary>
        /// 插入员工考核结果信息
        /// </summary>
        /// <param name="result"></param>
        /// <returns></returns>
        public static bool InsertCheckInfo(CheckResult result)
        {
            bool ret = true;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            if (CheckIfExistInfo(result))
                cmd.CommandText = "update tb_checkResult set Grade=@grade where ID=@empID and employeeIdChecked=@empIdChecked and ItemID=@itemID";
            else 
                cmd.CommandText = "insert into tb_checkResult values(@empID,@empIdChecked,@itemID,@grade)";
            cmd.Parameters.Add("@empID", SqlDbType.Int).Value = result.EmployeeID;
            cmd.Parameters.Add("@empIdChecked", SqlDbType.Int).Value = result.EmployeeIdChecked;
            cmd.Parameters.Add("@itemID", SqlDbType.Int).Value = result.ItemID;
            cmd.Parameters.Add("@grade", SqlDbType.Int).Value = result.Grade;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
                ret = false;
            }
            return ret;
        }
        #endregion


        #region 　 根据员工编号查找同部门员工考核结果
        /// <summary>
        /// 根据员工编号查找同部门员工考核结果
        /// </summary>
        /// <param name="deptname"></param>
        /// <returns></returns>
        public static DataTable GetCheckResultById(int id)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select a.ID,a.Name,b.deptName,a.Job,sum(Grade) as Total from tb_employee a,tb_department b ,tb_checkResult c where a.deptID=b.deptID and a.deptID=(select deptID from tb_employee d where d.ID=@id) and a.ID<>@id and c.ID=@id and a.ID=c.employeeIdChecked group by a.ID,Name,deptName,Job";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dt.Clear();
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
                sda.Fill(dt);
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dt;
        }
        #endregion


        #region　查找所有员工考核结果
        /// <summary>
        /// 查找所有员工考核结果
        /// </summary>
        /// <returns></returns>
        public static DataTable GetAllCheckResult()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select newtb.employeeIdChecked,Name,c.deptName,a.Comment,Total,newtb.ID from tb_comment a ,tb_employee b,tb_department c,(select employeeIdChecked,ID,sum(Grade) as Total from tb_checkResult group by ID,employeeIdChecked) newtb where a.ID=newtb.ID and a.employeeIdChecked=newtb.employeeIdChecked and b.ID=newtb.employeeIdChecked and b.deptID=c.deptID";
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dt.Clear();
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
                sda.Fill(dt);
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dt;
        }
        #endregion


        #region　根据部门名称查找部门员工考核结果
        /// <summary>
        ///  根据部门名称查找部门员工考核结果
        /// </summary>
        /// <param name="deptname"></param>
        /// <returns></returns>
        public static DataTable GetCheckResultByDeptName(string deptname)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select newtb.employeeIdChecked,Name,c.deptName,a.Comment,Total,newtb.ID from tb_comment a ,tb_employee b,tb_department c,(select employeeIdChecked,ID,sum(Grade) as Total from tb_checkResult group by ID,employeeIdChecked) newtb where a.ID=newtb.ID and a.employeeIdChecked=newtb.employeeIdChecked and b.ID=newtb.employeeIdChecked and b.deptID=c.deptID and c.deptName=@deptname";
            cmd.Parameters.Add("@deptname", SqlDbType.VarChar,50).Value = deptname;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dt.Clear();
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
                sda.Fill(dt);
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dt;
        }
        #endregion

        #region　根据部门名称和员工姓名查找该员工考核结果
        /// <summary>
        /// 根据部门名称和员工姓名查找该员工考核结果
        /// </summary>
        /// <param name="deptname">部门名称</param>
        /// <param name="empname">员工姓名</param>
        /// <returns></returns>
        public static DataTable GetCheckResult(string deptname, string empname)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select newtb.employeeIdChecked,Name,c.deptName,a.Comment,Total,newtb.ID from tb_comment a ,tb_employee b,tb_department c,(select employeeIdChecked,ID,sum(Grade) as Total from tb_checkResult group by ID,employeeIdChecked) newtb where a.ID=newtb.ID and a.employeeIdChecked=newtb.employeeIdChecked and b.ID=newtb.employeeIdChecked and b.deptID=c.deptID and c.deptName=@deptname and b.Name=@empname";
            cmd.Parameters.Add("@deptname", SqlDbType.VarChar, 50).Value = deptname;
            cmd.Parameters.Add("@empname", SqlDbType.VarChar, 10).Value = empname;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dt.Clear();
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
                sda.Fill(dt);
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dt;
        }
        #endregion

        #region　根据员工编号查找其考核总平均分
        /// <summary>
        /// 根据员工编号查找其考核总平均分
        /// </summary>
        /// <param name="id">员工编号</param>
        /// <returns></returns>
        public static int GetAvgGrade(int id)
        {
            int avg=0;
             SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select Avg(Total)as TotalAvg from (select employeeIdChecked,ID,sum(Grade) as Total from tb_checkResult group by ID,employeeIdChecked) newtb where newtb.employeeIdChecked=@id group by employeeIdChecked";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dt.Clear();
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
                sda.Fill(dt);
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return avg;
        }
        #endregion

        public static bool CheckIfExistInfo(CheckResult result)//是否存在信息
        {
            bool ret = true;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select count(*) from tb_checkResult where ID=@empID and employeeIdChecked=@empIdChecked and ItemID=@itemID";
            cmd.Parameters.Add("@empID", SqlDbType.Int).Value = result.EmployeeID;
            cmd.Parameters.Add("@empIdChecked", SqlDbType.Int).Value = result.EmployeeIdChecked;
            cmd.Parameters.Add("@itemID", SqlDbType.Int).Value = result.ItemID;
            cmd.Parameters.Add("@grade", SqlDbType.Int).Value = result.Grade;
            cmd.Connection = myconn;
            int n = 0;
            try
            {
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    n = sdr.GetInt32(0);
                }
                sdr.Close();
                if (n >= 1)
                    ret = true;
                else
                    ret = false;
            }
            catch (Exception e)
            {
                string msg = e.Message;
                ret = false;
            }
            return ret;
        }
    }
}
