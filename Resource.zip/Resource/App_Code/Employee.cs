﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace ResourceManage
{
    /// <summary>
    /// employee 的摘要说明
    /// </summary>
    public class Employee
    {
        #region 定义私有成员变量
        private int   e_ID;             //员工ID
        private string e_Name;        //员工姓名
        private string e_Sex;         //员工性别
        private DateTime e_Birthday;  //出生年月
        private bool e_MaritalStatus; //婚姻状况
        private string e_Learn;       //学历
        private string e_Major;       //专业
        private string e_PoliticsFace;//政治面貌
        private string e_NativePlace; //籍贯
        private string e_Race;        //民族
        private string e_Address;     //家庭住址
        private string e_Post;        //职称
        private string e_Job;         //职位
        private int  e_deptID;    //工作部门名称
        private bool e_Status;        //是否在职
        private string e_Superior;    //上级姓名
        private string e_Mobilephone; //移动电话
        private string e_Phone;       //固定电话
        private string e_Email;       //电子邮箱
        private string e_QQ;          //QQ
        private string e_MSN;         //MSN
        private string e_Interest;    //兴趣爱好
        private DateTime e_BeginWorkTime;  //参加工作时间
        private DateTime e_IntoCompanyTime;//进入公司时间
        private DateTime e_RiseSalaryTime; //起薪时间
        private DateTime e_IntoDeptTime;   //调入部门时间
        private DateTime e_TitleTime;      //职称时间
        private string e_ExperienceSkill;  //工作经验及职业技能
        private string e_PhotoPath;        //照片路径
        private string e_Remarks;          //备注

        #endregion

        #region 定义属性

        public int  E_ID
        {
            get
            {
                return e_ID;
            }
            set
            {
                e_ID = value;
            }
        }
        public string E_Name
        {
            get
            {
                return e_Name;
            }
            set
            {
                e_Name = value;
            }
        }
        public string E_Sex
        {
            get
            {
                return e_Sex;
            }
            set
            {
                e_Sex = value;
            }
        }
        public DateTime E_Birthday
        {
            get
            {
                return e_Birthday;
            }
            set
            {
                e_Birthday = value;
            }
        }
        public bool E_MaritalStatus
        {
            get
            {
                return e_MaritalStatus;
            }
            set
            {
                e_MaritalStatus = value;
            }
        }
        public string E_Learn
        {
            get
            {
                return e_Learn;
            }
            set
            {
                e_Learn = value;
            }
        }
        public string E_Major
        {
            get
            {
                return e_Major;
            }
            set
            {
                e_Major = value;
            }
        }
        public string E_PoliticsFace
        {
            get
            {
                return e_PoliticsFace;
            }
            set
            {
                e_PoliticsFace = value;
            }
        }
        public string E_NativePlace
        {
            get
            {
                return e_NativePlace;
            }
            set
            {
                e_NativePlace = value;
            }
        }
        public string E_Race
        {
            get
            {
                return e_Race;
            }
            set
            {
                e_Race = value;
            }
        }

 
        public string E_Address
        {
            get
            {
                return e_Address;
            }
            set
            {
                e_Address = value;
            }
        }
        public string E_Post
        {
            get
            {
                return e_Post;
            }
            set
            {
                e_Post = value;
            }
        }
        public string E_Job
        {
            get
            {
                return e_Job;
            }
            set
            {
                e_Job = value;
            }
        }
        public int E_deptID
        {
            get
            {
                return e_deptID;
            }
            set
            {
                e_deptID = value;
            }
        }
        public bool E_Status
        {
            get
            {
                return e_Status;
            }
            set
            {
                e_Status = value;
            }
        }
        public string E_Superior
        {
            get
            {
                return e_Superior;
            }
            set
            {
                e_Superior = value;
            }
        }
        public string E_MobilePhone
        {
            get
            {
                return e_Mobilephone;
            }
            set
            {
                e_Mobilephone = value;
            }
        }
        public string E_Phone
        {
            get
            {
                return e_Phone;
            }
            set
            {
                e_Phone = value;
            }
        }
        public string E_Email
        {
            get
            {
                return e_Email;
            }
            set
            {
                e_Email = value;
            }
        }
        public string E_QQ
        {
            get
            {
                return e_QQ;
            }
            set
            {
                e_QQ = value;
            }
        }
        public string E_MSN
        {
            get
            {
                return e_MSN;
            }
            set
            {
                e_MSN = value;
            }
        }
        public string E_Interest
        {
            get
            {
                return e_Interest;
            }
            set
            {
                e_Interest = value;
            }
        }
        public DateTime E_BeginWorkTime
        {
            get
            {
                return e_BeginWorkTime;
            }
            set
            {
                e_BeginWorkTime = value;
            }
        }
        public DateTime E_IntoCompanyTime
        {
            get
            {
                return e_IntoCompanyTime;
            }
            set
            {
                e_IntoCompanyTime = value;
            }
        }
        public DateTime E_RiseSalaryTime
        {
            get
            {
                return e_RiseSalaryTime;
            }
            set
            {
                e_RiseSalaryTime = value;
            }
        }
        public DateTime E_IntoDeptTime
        {
            get
            {
                return e_IntoDeptTime;
            }
            set
            {
                e_IntoDeptTime = value;
            }
        }
        public DateTime E_TitleTime
        {
            get
            {
                return e_TitleTime;
            }
            set
            {
                e_TitleTime = value;
            }
        }
        public string E_ExperienceSkill
        {
            get
            {
                return e_ExperienceSkill;
            }
            set
            {
                e_ExperienceSkill = value;
            }
        }
        public string E_PhotoPath
        {
            get
            {
                return e_PhotoPath;
            }
            set
            {
                e_PhotoPath = value;
            }
        }
        public string E_Remarks
        {
            get
            {
                return e_Remarks;
            }
            set
            {
                e_Remarks = value;
            }
        }

        #endregion
        public Employee()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
        }
    }
}
