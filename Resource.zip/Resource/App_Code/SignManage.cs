﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace ResourceManage
{
    /// <summary>
    /// SignManage 的摘要说明
    /// </summary>
    public class SignManage
    {
        public static SqlConnection myconn;
        static  SignManage()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
            myconn = new SqlConnection();
            myconn.ConnectionString = ConfigurationManager.AppSettings["ConnectionString"];
            myconn.Open();
        }
        ~SignManage()
        {
            myconn.Close();
        }

        #region　插入员工签到信息
        /// <summary>
        /// 插入员工签到信息
        /// </summary>
        /// <param name="signtime">签到时间</param>
        /// <param name="late">是否迟到</param>
        /// <param name="quit">是否早退</param>
        /// <param name="latetime">迟到时间</param>
        /// <param name="quittime">早退时间</param>
        public static void AddSignInfo(DateTime signtime, bool late, bool quit, int overtime,int eID)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into tb_sign(SignTime,IfLate,IfQuit,OverTime,EmpID) values(@signtime,@late,@quit,@overtime,@eID)";
            cmd.Parameters.Add("@signtime", SqlDbType.DateTime).Value = signtime;
            cmd.Parameters.Add("@late", SqlDbType.Bit).Value = late;
            cmd.Parameters.Add("@quit", SqlDbType.Bit).Value = quit;
            cmd.Parameters.Add("@overtime", SqlDbType.Int).Value = overtime;
            cmd.Parameters.Add("@eID", SqlDbType.Int).Value = eID;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }

        }
        #endregion

        #region　根据姓名和部门名称查询签到信息
        /// <summary>
        /// 根据姓名和部门名称查询签到信息
        /// </summary>
        /// <param name="name">员工姓名</param>
        /// <returns>签到信息表</returns>
        public static DataTable GetSignInfoByName(string name,string deptname)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select tb_sign.* ,Name from tb_sign ,tb_employee,tb_department where tb_department.deptID=tb_employee.deptID and tb_sign.EmpID=tb_employee.ID and tb_department.deptName=@deptname and tb_employee.Name=@name";
            cmd.Parameters.Add("@name", SqlDbType.VarChar, 10).Value = name;
            cmd.Parameters.Add("@deptname", SqlDbType.VarChar, 50).Value = deptname;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dt.Clear();
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
                sda.Fill(dt);
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dt;
        }
        #endregion


        #region　查找所有员工签到信息
        /// <summary>
        /// 查找所有员工签到信息
        /// </summary>
        /// <returns></returns>
        public static DataTable GetAllSignInfo()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select tb_sign.*,tb_employee.Name from tb_sign,tb_employee where tb_sign.EmpID=tb_employee.ID ";
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dt.Clear();
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
                sda.Fill(dt);
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dt;
        }
        #endregion 


        #region 查找同一部门的所有员工签到信息
        /// <summary>
        /// 查找同一部门的所有员工签到信息
        /// </summary>
        /// <param name="id">同一部门的id</param>
        /// <returns>同一部门的所有员工签到信息表</returns>
        public static DataTable GetAllInSameDept(string deptname)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select tb_sign.* ,Name from tb_sign ,tb_employee,tb_department where tb_department.deptID=tb_employee.deptID and tb_sign.EmpID=tb_employee.ID and tb_department.deptName=@deptname";
            cmd.Parameters.Add("@deptname", SqlDbType.VarChar,50).Value =deptname;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dt.Clear();
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
                sda.Fill(dt);
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dt;
        }
        #endregion

        #region
        /// <summary>
        /// 查找所有的年份
        /// </summary>
        /// <returns>返回年份的视图</returns>
        public static DataView GetAllYear()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select distinct Year(SignTime) years from tb_sign order by years ";
            cmd.Connection = myconn;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataView dv = new DataView();
            try
            {
                cmd.ExecuteNonQuery();
                sda.Fill(ds, "year");
                dv = ds.Tables[0].DefaultView;
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dv;
        }
        #endregion

        #region　计算总共迟到早退的次数
        /// <summary>
        /// 计算总共迟到早退的次数
        /// </summary>
        /// <param name="id">员工ID</param>
        /// <returns>返回总共迟到早退的次数</returns>
        public static int LateOrQuitTime(int id)
        {
            int total = 0;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select count(*)  from tb_sign where EmpID=@id and IfLate=1 or IfQuit=1";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
            cmd.Connection = myconn;
            try
            {
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    total = sdr.GetInt16(0);
                }
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return total ;
        }
        #endregion

        #region
        /// <summary>
        /// 查找加班时间
        /// </summary>
        /// <param name="id">员工ID</param>
        /// <param name="years">年份</param>
        /// <param name="months">月份</param>
        /// <returns>返回加班时间视图</returns>
        public static DataView GetOverTimeInfo(int id, string years, string months)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select SignTime,OverTime from tb_sign where EmpID=@id and Year(SignTime)=@years and Month(SignTime)=@months and OverTime<>0 ";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
            cmd.Parameters.Add("@years", SqlDbType.VarChar, 10).Value = years;
            cmd.Parameters.Add("@months", SqlDbType.VarChar, 10).Value = months;
            cmd.Connection = myconn;
            SqlDataAdapter sda = new SqlDataAdapter();
            DataSet ds = new DataSet();
            DataView dv = new DataView();
            try
            {
                sda.Fill(ds, "overtime");
                dv = ds.Tables[0].DefaultView;
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dv;
        }
        #endregion
    }

}
