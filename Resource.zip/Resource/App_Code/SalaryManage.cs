﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace ResourceManage
{
    /// <summary>
    /// SalaryManage 的摘要说明
    /// </summary>
    public class SalaryManage
    {
        public static SqlConnection myconn;
        static SalaryManage()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
            myconn = new SqlConnection();
            myconn.ConnectionString = ConfigurationManager.AppSettings["ConnectionString"];
            myconn.Open();
        }

        ~SalaryManage()
        {
            myconn.Close();
        }

        #region 查找所有工资表信息
        /// <summary>
        /// 查找所有工资表信息
        /// </summary>
        /// <param name="deptname">所属部门名称</param>
        /// <param name="year">年份</param>
        /// <param name="month">月份</param>
        /// <returns>返回工资信息表</returns>
        public static DataTable  GetAllInfo(string deptname,string year,string month)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select a.ID,a.Name,c.deptName,a.Job,b.BaseSalary,b.ResultsWage,b.WholeAttendancePrice,b.OverTimePay,b.AddUp from tb_employee a,tb_salary b,tb_department c where a.ID=b.ID and c.deptID=a.deptID and c.deptName=@deptname and b.Year=@year and b.Month=@month order by a.ID";
            //cmd.CommandText = "select a.ID,a.Name,a.deptName,a.Job,b.BaseSalary,b.ResultsWage,b.WholeAttendancePrice,b.OverTimePay,b.AddUp from tb_employee a,tb_salary b where a.ID=b.ID and a.deptName=@deptname and b.Year=@year and b.Month=@month order by a.ID";
            cmd.Parameters.Add("@deptname", SqlDbType.VarChar, 50).Value = deptname.Trim();
            cmd.Parameters.Add("@year", SqlDbType.VarChar, 10).Value = year;
            cmd.Parameters.Add("@month", SqlDbType.VarChar, 10).Value = month;
            cmd.Connection = myconn;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dt.Clear();
            try
            {
                cmd.ExecuteNonQuery();
                sda.Fill(dt);
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dt;
        }
        #endregion

        #region 根据员工ID查找员工的姓名,岗位各基本工资
        /// <summary>
        /// 根据员工ID查找员工的姓名,岗位各基本工资
        /// </summary>
        /// <param name="id">员工ID</param>
        /// <returns>返回信息视图</returns>
        public static DataView GetSomeInfoById(int id)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText="select a.Name,a.Job,b.Salary from tb_employee a,tb_jobsalary b where a.Job=b.Job and a.ID=@id";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
            cmd.Connection = myconn;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataView dv = new DataView();
            try
            {
                sda.Fill(ds, "info");
                dv = ds.Tables[0].DefaultView;
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dv;
        }
        #endregion

        #region 添加员工工资信息
        /// <summary>
        /// 添加员工工资信息
        /// </summary>
        /// <param name="id">员工ID</param>
        /// <param name="years">年份</param>
        /// <param name="months">月份</param>
        /// <param name="basesalary">基本岗位工资</param>
        /// <param name="resultswage">绩效工资</param>
        /// <param name="attendance">全勤奖</param>
        /// <param name="overtimepay">加班费</param>
        /// <param name="total">总工资</param>
        /// <returns>返回添加操作是否成功的标志</returns>
        public static bool AddSalaryInfo(int  id, string years, string months, int basesalary, int resultswage, int attendance, int overtimepay, int total)
        {
            bool ret = true;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into tb_salary(ID,Year,Month,BaseSalary,ResultsWage,WholeAttendancePrice,OverTimePay,AddUp) values(@id,@years,@months,@base,@resultswage,@attendance,@overpay,@total)";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
            cmd.Parameters.Add("@years", SqlDbType.VarChar, 10).Value = years;
            cmd.Parameters.Add("@months", SqlDbType.VarChar, 10).Value = months;
            cmd.Parameters.Add("@base", SqlDbType.Int).Value = basesalary;
            cmd.Parameters.Add("@resultswage", SqlDbType.Int).Value = resultswage;
            cmd.Parameters.Add("@attendance", SqlDbType.Int).Value = attendance;
            cmd.Parameters.Add("@overpay", SqlDbType.Int).Value = overtimepay;
            cmd.Parameters.Add("@total", SqlDbType.Int).Value = total;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
                ret = false;
            }
            return ret;
        }
        #endregion

        public static bool UpdateInfo(int id, string years, string months, int basesalary, int resultswage, int attendance, int overtimepay, int total)
        {
            bool ret = true;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update tb_salary set BaseSalary=@base,ResultsWage=@resultswage,WholeAttendancePrice=@attendance,OverTimePay=@overpay,AddUp=@total where ID=@id and Year=@years and Month=@months";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
            cmd.Parameters.Add("@years", SqlDbType.VarChar, 10).Value = years;
            cmd.Parameters.Add("@months", SqlDbType.VarChar, 10).Value = months;
            cmd.Parameters.Add("@base", SqlDbType.Int).Value = basesalary;
            cmd.Parameters.Add("@resultswage", SqlDbType.Int).Value = resultswage;
            cmd.Parameters.Add("@attendance", SqlDbType.Int).Value = attendance;
            cmd.Parameters.Add("@overpay", SqlDbType.Int).Value = overtimepay;
            cmd.Parameters.Add("@total", SqlDbType.Int).Value = total;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
                ret = false;
            }
            return ret;
        }

        public static bool CheckIfExistInfo(int id, string years, string months)//信息是否存在
        {
            bool ret = false;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select count(*) from tb_salary where ID=@id and Year=@year and Month=@months";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
            cmd.Parameters.Add("@year", SqlDbType.VarChar, 10).Value = years;
            cmd.Parameters.Add("@months", SqlDbType.VarChar, 10).Value = months;
           
            cmd.Connection = myconn;
            try
            {
                int n=0;
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    n = sdr.GetInt32(0);
                }
                sdr.Close();
                if (n >= 1)
                    ret = true;
                else
                    ret = false;
            }
            catch (Exception e)
            {
                string msg = e.Message;
                ret = false;
            }
            return ret;
        }
    }
}
