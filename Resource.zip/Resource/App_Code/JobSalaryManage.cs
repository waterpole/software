﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace ResourceManage
{
    /// <summary>
    /// JobSalaryManage 的摘要说明
    /// </summary>
    public class JobSalaryManage
    {
        public static SqlConnection myconn;

        static  JobSalaryManage()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
            myconn = new SqlConnection();
            myconn.ConnectionString = ConfigurationManager.AppSettings["ConnectionString"];
            myconn.Open();
        }
        ~JobSalaryManage()
        {
            myconn.Close();
        }

        #region
        /// <summary>
        /// 添加岗位工资表信息
        /// </summary>
        /// <param name="job">岗位</param>
        /// <param name="salary">岗位基本工资</param>
        /// <returns>返回添加操作是否成功的标志</returns>
        public static bool AddJobSalary(string job, int salary)
        {
            bool ret = true;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into tb_jobsalary values(@job,@salary)";
            cmd.Parameters.Add("@job", SqlDbType.VarChar, 50).Value = job;
            cmd.Parameters.Add("@salary", SqlDbType.Int).Value = salary;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
                ret = false;
            }
            return ret;
        }
        #endregion

        #region
        /// <summary>
        /// 查找所有岗位工资信息
        /// </summary>
        /// <returns>返回岗位工资信息表</returns>
        public static DataTable GetAllInfo()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from tb_jobsalary order by Job";
            cmd.Connection = myconn;
            SqlDataAdapter sda=new SqlDataAdapter (cmd);
            DataTable dt=new DataTable ();
            dt.Clear();
            try
            {
                cmd.ExecuteNonQuery();
                sda.Fill(dt);
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dt;
        }
        #endregion

        #region
        /// <summary>
        /// 更新岗位工资信息
        /// </summary>
        /// <param name="job">岗位</param>
        /// <param name="salary">岗位工资</param>
        /// <returns>返回更新操作是否成功的标志</returns>
        public static bool UpdateInfo(string job, int salary)
        {
            bool ret = true;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update tb_jobsalary set Salary=@salary where Job=@job";
            cmd.Parameters.Add("@job", SqlDbType.VarChar, 50).Value = job;
            cmd.Parameters.Add("@salary", SqlDbType.Int).Value = salary;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
                ret = false;
            }
            return ret;
        }
        #endregion

        #region
        /// <summary>
        /// 删除岗位工资信息
        /// </summary>
        /// <param name="job">岗位</param>
        /// <returns>返回删除操作是否成功的标志</returns>
        public static bool DeleteInfo(string job)
        {
            bool ret = true;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from tb_jobsalary where Job=@job";
            cmd.Parameters.Add("@job", SqlDbType.VarChar, 50).Value = job;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
                ret = false;
            }
            return ret;
        }
        #endregion

        #region
        /// <summary>
        /// 查找所有职位信息
        /// </summary>
        /// <returns>返回职位信息视图</returns>
        public static DataView GetAllJob()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select distinct Job from tb_jobsalary ";
            cmd.Connection = myconn;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataView dv = new DataView();
            try
            {
                sda.Fill(ds, "job");
                dv = ds.Tables[0].DefaultView;
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dv;
        }
        #endregion
    }
}
