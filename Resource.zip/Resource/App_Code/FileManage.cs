﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace ResourceManage
{
    /// <summary>
    /// FileManage 的摘要说明
    /// </summary>
    public class FileManage
    {
        public static SqlConnection myconn;
        static FileManage()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
            myconn = new SqlConnection();
            myconn.ConnectionString = ConfigurationManager.AppSettings["ConnectionString"];
            myconn.Open();
        }
        ~FileManage()
        {
            myconn.Close();
        }

        #region  添加文件信息
        /// <summary>
        /// 添加文件信息
        /// </summary>
        /// <param name="sender">文件发送者</param>
        /// <param name="accepter">文件接收者</param>
        /// <param name="title">文件标题</param>
        /// <param name="time">发送时间</param>
        /// <param name="content">文件内容</param>
        /// <param name="path">文件附件路径</param>
        /// <param name="filename">文件名</param>
        /// <param name="ifreceive">是否接收</param>
        /// <returns>返回添加文件操作是否成功标志</returns>
        public static bool AddFileInfo(string sender, string accepter, string title, DateTime time, string content, string path, string filename, Boolean ifreceive)
        {
            bool ret = true;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into tb_file(FileSender,FileAccepter,FileTitle,FileTime,FileContent,Path,FileName,IfReceive) values(@sender,@accepter,@title,@time,@content,@path,@filename,@ifreceive)";
            cmd.Parameters.Add("@sender", SqlDbType.VarChar, 20).Value = sender;
            cmd.Parameters.Add("@accepter", SqlDbType.VarChar, 20).Value = accepter;
            cmd.Parameters.Add("@title", SqlDbType.VarChar, 50).Value = title;
            cmd.Parameters.Add("@time", SqlDbType.DateTime).Value = time;
            cmd.Parameters.Add("@content", SqlDbType.Text).Value = content;
            cmd.Parameters.Add("@path", SqlDbType.VarChar, 100).Value = path;
            cmd.Parameters.Add("@filename", SqlDbType.VarChar, 50).Value = filename;
            cmd.Parameters.Add("@ifreceive", SqlDbType.Bit).Value = ifreceive;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
                ret = false;
            }
            return ret;
        }
        #endregion

        #region  查找文件总记录数
        /// <summary>
        /// 查找文件总记录数
        /// </summary>
        /// <returns></returns>
        public static int GetFileCount(string accepter)
        {
            int num = 0;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            if (accepter == "")
            {
                cmd.CommandText = "select count(*) as num from tb_file ";
            }
            else
            {
                cmd.CommandText = "select count(*) as num from tb_file where FileAccepter=@accepter ";
                cmd.Parameters.Add("@accepter", SqlDbType.VarChar, 20).Value = accepter;
            }
            cmd.Connection = myconn;
            SqlDataReader sdr = cmd.ExecuteReader();

            try
            {
                if (sdr.Read())
                {
                    num = Convert.ToInt32(sdr["num"].ToString());
                }
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            sdr.Close();
            return num;
        }
        #endregion

        #region  //查找未接收或已接收的文件总记录数
        /// <summary>
        /// 查找未接收或已接收的文件总记录数
        /// </summary>
        /// <param name="ifreceive">是否接收</param>
        /// <returns></returns>

        public static int GetFileCount(bool ifreceive, string accepter)
        {
            int num = 0;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            if (accepter == "")
            {
                cmd.CommandText = "select count(*) as num from tb_file where IfReceive=@ifreceived ";
                cmd.Parameters.Add("@ifreceived", SqlDbType.Bit).Value = ifreceive;
            }
            else
            {
                cmd.CommandText = "select count(*) as num from tb_file where IfReceive=@ifreceived and FileAccepter=@accepter ";
                cmd.Parameters.Add("@ifreceived", SqlDbType.Bit).Value = ifreceive;
                cmd.Parameters.Add("@accepter", SqlDbType.VarChar, 20).Value = accepter;
            }
            cmd.Connection =myconn ;
            SqlDataReader sdr = cmd.ExecuteReader();

            try
            {
                if (sdr.Read())
                {
                    num = Convert.ToInt32(sdr["num"].ToString());
                }
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            sdr.Close();
            return num;
        }
        #endregion

        #region  查找指定页的文件信息量
        /// <summary>
        ///  查找指定页的文件信息量
        /// </summary>
        /// <param name="currentpage">当前页数</param>
        /// <param name="pagesize">一页可显示的总记录数</param>
        /// <returns>所要查找页要显示的所有记录数</returns>
        public static DataTable GetFileInfo(int currentpage, int pagesize, string accepter)
        {
            int startIndex = currentpage * pagesize;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            if (accepter == "")
            {
                cmd.CommandText = "select * from tb_file ";
            }
            else
            {
                cmd.CommandText = "select * from tb_file where FileAccepter=@accepter ";
                cmd.Parameters.Add("@accepter", SqlDbType.VarChar, 20).Value = accepter;
            }
            cmd.Connection = myconn;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            dt.Clear();
            try
            {
                sda.Fill(ds, startIndex, pagesize, "filelist");
                dt = ds.Tables["filelist"];
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dt;
        }
        #endregion


        #region  查找指定页内的未接收或已接收的文件信息
        /// <summary>
        /// 查找指定页内的未接收或已接收的文件信息
        /// </summary>
        /// <param name="ifreceive">接收状态</param>
        /// <param name="currentpage">当前页号</param>
        /// <param name="pagesize">一页内最多能显示的总记录数</param>
        /// <returns>返回所有限定范围内的信息</returns>
        public static DataTable FileGet(bool ifreceive, int currentpage, int pagesize, string accepter)
        {
            int startIndex = currentpage * pagesize;
            SqlCommand command = new SqlCommand();
            command.CommandType = CommandType.Text;
            if (accepter == "")
            {
                command.CommandText = "select * from tb_file where IfReceive=@ifreceived ";
                command.Parameters.Add("@ifreceived", SqlDbType.Bit).Value = ifreceive;
            }
            else
            {
                command.CommandText = "select * from tb_file where IfReceive=@ifreceived and FileAccepter=@accepter ";
                command.Parameters.Add("@ifreceived", SqlDbType.Bit).Value = ifreceive;
                command.Parameters.Add("@accepter", SqlDbType.VarChar, 20).Value = accepter;
            }
            command.Connection = myconn ;
            SqlDataAdapter sda = new SqlDataAdapter(command);
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            dt.Clear();
            try
            {
                sda.Fill(ds, startIndex, pagesize, "filelist");
                dt = ds.Tables["filelist"];
            }
            catch (Exception e)
            {
                string msg = e.Message;

            }
            command.Parameters.Clear();
            return dt;

        }
        #endregion

//**
       
        #region  更新接收状态
        /// <summary>
        /// 更新接收状态
        /// </summary>
        /// <param name="fileid">文件ID号</param>
        public static void UpdateAccepteStatus(int fileid)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update tb_file set IfReceive=1 where FileID=@fileid";
            cmd.Parameters.Add("@fileid", SqlDbType.Int).Value = fileid;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return;
        }
        #endregion

        #region  根据接收者查找所有文件信息
        /// <summary>
        /// 根据接收者查找所有文件信息
        /// </summary>
        /// <param name="accepter">接收者</param>
        /// <returns>文件信息表</returns>
        public static DataTable GetFileInfoByAccepter(string accepter)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from tb_file where FileAccepter=@accepter ";
            cmd.Parameters.Add("@accepter", SqlDbType.VarChar, 20).Value = accepter;
            cmd.Connection = myconn;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dt.Clear();
            try
            {
                cmd.ExecuteNonQuery();
                sda.Fill(dt);
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return dt;
        }
        #endregion

        #region  根据文件ID查找文件信息
        /// <summary>
        /// 根据文件ID查找文件信息
        /// </summary>
        /// <param name="fileid">文件ID</param>
        /// <returns>文件信息</returns>
        public static DataSet GetFileByFileId(int fileid)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from tb_file where FileID=@fileid ";
            cmd.Parameters.Add("@fileid", SqlDbType.Int).Value =fileid;
            cmd.Connection = myconn;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            ds.Clear();
            try
            {
                cmd.ExecuteNonQuery();
                sda.Fill(ds);
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return ds;
        }
        #endregion

        #region  删除文件信息
        /// <summary>
        /// 删除文件信息
        /// </summary>
        /// <param name="fileid">文件ID号</param>
        public static void DeleteFileByFileId(int fileid)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from tb_file where FileID=@fileid ";
            cmd.Parameters.Add("@fileid", SqlDbType.Int).Value =fileid;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
        }
        #endregion
    }
}
