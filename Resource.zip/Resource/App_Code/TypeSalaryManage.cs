﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace ResourceManage
{
    /// <summary>
    /// TypeSalaryManage 的摘要说明
    /// </summary>
    public class TypeSalaryManage
    {
        public static SqlConnection myconn;
        static  TypeSalaryManage()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
            myconn = new SqlConnection();
            myconn.ConnectionString = ConfigurationManager.AppSettings["ConnectionString"];
            myconn.Open();
        }

        ~TypeSalaryManage()
        {
            myconn.Close();
        }

        #region
        /// <summary>
        /// 查找所有的类型工资表
        /// </summary>
        /// <returns>返回类型工资信息表</returns>
        public static DataTable GetAllInfo()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from tb_typesalary";
            cmd.Connection = myconn;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dt.Clear();
            try
            {
                sda.Fill(dt);
            }
            catch(Exception e)
            {
                string msg=e.Message;
            }
            return dt;
        }
        #endregion

        #region
        public static void UpdateInfo(string type, int typesalary, string unit)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update tb_typesalary set TypeSalary=@typesalary,Unit=@unit where Type=@type";
            cmd.Parameters.Add("@type", SqlDbType.VarChar, 50).Value = type;
            cmd.Parameters.Add("@typesalary", SqlDbType.Int).Value = typesalary;
            cmd.Parameters.Add("@unit", SqlDbType.VarChar, 10).Value = unit;
            cmd.Connection = myconn;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
        }
        #endregion

        #region
        public static int  GetInfoByType(string type)
        {
            int salary = 0;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select TypeSalary from tb_typesalary  where Type=@type";
            cmd.Parameters.Add("@type", SqlDbType.VarChar, 50).Value = type;
            cmd.Connection = myconn;
            try
            {
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    salary = sdr.GetInt16(0);
                }
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
            return salary;
        }
        #endregion
    }
}
