﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ResourceManage;

public partial class usualUser_showNews : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int newsid=Convert.ToInt32(Request.QueryString["NewsID"]);
        string newsID = Request.QueryString["NewsID"];
        string Readed = Request.QueryString["Readed"];
        News newslist = new News();
        newslist = NewsManage.GetNewsById(newsid);
        if (newslist != null)
        {
            this.lbNewsTitle.Text = newslist.NewsTitle;
            this.lbNewsCreator.Text = newslist.NewsCreator;
            this.lbNewsContent.Text = newslist.NewsContent;
            this.lbNewsPublishDate.Text =newslist.NewsPublishDate.ToString();
        }
        if (Readed =="true")
        {
            NewsManage.UpdateViewCounter(newsid);
        }
    }
}
