﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ResourceManage;

public partial class usualUser_showRecruit : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int recruitID = Convert.ToInt32(Request.QueryString["recruitID"]);
        Recruit recruit = new Recruit();
        recruit = RecruitManage.GetRecruitInfoById(recruitID);
        if (recruit != null)
        {
            this.lbCompanyName.Text = recruit.CompanyName;
            this.lbIntroduction.Text = recruit.Introduction;
            this.lbRecruitPost.Text = recruit.RecruitPost;
            this.lbEmail.Text = recruit.Email;
            this.lbPubDate.Text =recruit.PublishDate.ToString("yyyy-MM-dd");
            this.lbWorkPlace.Text = recruit.WorkPlace;
            this.lbRecruitNum.Text =recruit.RecruitNum.ToString();
            this.lbWorkTimeLimit.Text = recruit.WorkTimeLimit;
            this.lbEnglishRequest.Text = recruit.EnglishRequest;
            this.lbSalaryScope.Text = recruit.SalaryScope;
            this.lbLearnRequest.Text = recruit.LearnRequest;
            this.txbPostDescription.Text = recruit.PostDescription;
        }
    }
}
